.class public final LD1/d;
.super Landroid/animation/AnimatorListenerAdapter;
.source "SourceFile"


# instance fields
.field private mViewBounds:LD1/f;


# direct methods
.method public constructor <init>(LD1/f;)V
    .locals 0

    invoke-direct {p0}, Landroid/animation/AnimatorListenerAdapter;-><init>()V

    iput-object p1, p0, LD1/d;->mViewBounds:LD1/f;

    return-void
.end method
