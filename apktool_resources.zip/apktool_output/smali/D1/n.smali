.class public interface abstract LD1/n;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method

.method public abstract c()V
.end method

.method public abstract d(LD1/o;)V
.end method

.method public abstract e()V
.end method
