.class public final LA/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB2/f;


# instance fields
.field public final synthetic d:I

.field public final synthetic e:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    iput p1, p0, LA/d;->d:I

    iput-object p2, p0, LA/d;->e:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;
    .locals 1

    iget p2, p0, LA/d;->d:I

    packed-switch p2, :pswitch_data_0

    check-cast p1, Ljava/lang/Number;

    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    move-result p1

    iget-object p2, p0, LA/d;->e:Ljava/lang/Object;

    check-cast p2, Lo0/p0;

    iget-object p2, p2, Lo0/p0;->d:LD/c0;

    invoke-virtual {p2, p1}, LD/c0;->g(F)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_0
    check-cast p1, Ls/f;

    instance-of p2, p1, Ls/d;

    iget-object v0, p0, LA/d;->e:Ljava/lang/Object;

    check-cast v0, LN/s;

    if-eqz p2, :cond_0

    invoke-virtual {v0, p1}, LN/s;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_0
    instance-of p2, p1, Ls/e;

    if-eqz p2, :cond_1

    check-cast p1, Ls/e;

    iget-object p1, p1, Ls/e;->a:Ls/d;

    invoke-virtual {v0, p1}, LN/s;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_1
    instance-of p2, p1, Ls/b;

    if-eqz p2, :cond_2

    invoke-virtual {v0, p1}, LN/s;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_2
    instance-of p2, p1, Ls/c;

    if-eqz p2, :cond_3

    check-cast p1, Ls/c;

    iget-object p1, p1, Ls/c;->a:Ls/b;

    invoke-virtual {v0, p1}, LN/s;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_3
    instance-of p2, p1, Ls/i;

    if-eqz p2, :cond_4

    invoke-virtual {v0, p1}, LN/s;->add(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_4
    instance-of p2, p1, Ls/j;

    if-eqz p2, :cond_5

    check-cast p1, Ls/j;

    iget-object p1, p1, Ls/j;->a:Ls/i;

    invoke-virtual {v0, p1}, LN/s;->remove(Ljava/lang/Object;)Z

    goto :goto_0

    :cond_5
    instance-of p2, p1, Ls/h;

    if-eqz p2, :cond_6

    check-cast p1, Ls/h;

    iget-object p1, p1, Ls/h;->a:Ls/i;

    invoke-virtual {v0, p1}, LN/s;->remove(Ljava/lang/Object;)Z

    :cond_6
    :goto_0
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
