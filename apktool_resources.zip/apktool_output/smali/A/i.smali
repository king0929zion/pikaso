.class public final LA/i;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LA/i;->e:I

    iput-object p2, p0, LA/i;->f:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method

.method public constructor <init>(LA/P;)V
    .locals 2

    const/4 v0, 0x2

    iput v0, p0, LA/i;->e:I

    sget-object v1, LG1/c;->a:LL/a;

    .line 2
    iput-object p1, p0, LA/i;->f:Ljava/lang/Object;

    invoke-direct {p0, v0}, Lp2/h;-><init>(I)V

    return-void
.end method

.method public constructor <init>(Lt/p;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LA/i;->e:I

    sget-object v0, LG1/c;->a:LL/a;

    .line 3
    iput-object p1, p0, LA/i;->f:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 21

    move-object/from16 v1, p0

    const/4 v0, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget v8, v1, LA/i;->e:I

    packed-switch v8, :pswitch_data_0

    move-object/from16 v0, p1

    check-cast v0, LD/n;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    and-int/2addr v2, v5

    if-ne v2, v4, :cond_1

    invoke-virtual {v0}, LD/n;->y()Z

    move-result v2

    if-nez v2, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, LD/n;->K()V

    goto :goto_1

    :cond_1
    :goto_0
    iget-object v2, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v2, Lo0/a;

    invoke-virtual {v2, v6, v0}, Lo0/a;->a(ILD/n;)V

    :goto_1
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :pswitch_0
    move-object/from16 v0, p1

    check-cast v0, LW/o;

    move-object/from16 v2, p2

    check-cast v2, LZ/d;

    iget-object v3, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v3, Ln0/Y;

    iget-object v4, v3, Ln0/Y;->n:Ln0/z;

    invoke-virtual {v4}, Ln0/z;->v()Z

    move-result v4

    if-eqz v4, :cond_2

    iget-object v4, v3, Ln0/Y;->n:Ln0/z;

    invoke-static {v4}, Ln0/C;->s(Ln0/z;)Ln0/e0;

    move-result-object v4

    check-cast v4, Lo0/u;

    invoke-virtual {v4}, Lo0/u;->getSnapshotObserver()Ln0/g0;

    move-result-object v4

    sget-object v5, Ln0/Y;->G:LW/F;

    sget-object v5, Ln0/J;->g:Ln0/J;

    new-instance v8, Ln0/D;

    invoke-direct {v8, v3, v0, v2, v7}, Ln0/D;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    invoke-virtual {v4, v3, v5, v8}, Ln0/g0;->a(Ln0/f0;Lo2/c;Lo2/a;)V

    iput-boolean v6, v3, Ln0/Y;->E:Z

    goto :goto_2

    :cond_2
    iput-boolean v7, v3, Ln0/Y;->E:Z

    :goto_2
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :pswitch_1
    move-object/from16 v0, p1

    check-cast v0, LP/l;

    move-object/from16 v2, p2

    check-cast v2, LP/j;

    instance-of v3, v2, LP/g;

    if-eqz v3, :cond_3

    check-cast v2, LP/g;

    iget-object v2, v2, LP/g;->a:Lp2/h;

    invoke-static {v5, v2}, Lp2/r;->c(ILjava/lang/Object;)V

    sget-object v3, LP/i;->a:LP/i;

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    iget-object v5, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v5, LD/n;

    invoke-interface {v2, v3, v5, v4}, Lo2/f;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/io/Serializable;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LP/l;

    invoke-static {v5, v2}, LP/m;->a(LD/n;LP/l;)LP/l;

    move-result-object v2

    :cond_3
    invoke-interface {v0, v2}, LP/l;->c(LP/l;)LP/l;

    move-result-object v0

    return-object v0

    :pswitch_2
    move-object/from16 v0, p1

    check-cast v0, Ljava/util/Set;

    move-object/from16 v5, p2

    check-cast v5, LN/h;

    :goto_3
    iget-object v5, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v5, LN/v;

    iget-object v8, v5, LN/v;->b:Ljava/util/concurrent/atomic/AtomicReference;

    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v9

    if-nez v9, :cond_4

    move-object v10, v0

    check-cast v10, Ljava/util/Collection;

    goto :goto_4

    :cond_4
    instance-of v10, v9, Ljava/util/Set;

    if-eqz v10, :cond_5

    new-array v10, v4, [Ljava/util/Set;

    aput-object v9, v10, v6

    aput-object v0, v10, v7

    invoke-static {v10}, Ld2/l;->U([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v10

    goto :goto_4

    :cond_5
    instance-of v10, v9, Ljava/util/List;

    if-eqz v10, :cond_9

    move-object v10, v9

    check-cast v10, Ljava/util/Collection;

    invoke-static {v0}, LZ/b;->D(Ljava/lang/Object;)Ljava/util/List;

    move-result-object v11

    invoke-static {v10, v11}, Ld2/k;->g0(Ljava/util/Collection;Ljava/util/List;)Ljava/util/ArrayList;

    move-result-object v10

    :cond_6
    :goto_4
    invoke-virtual {v8, v9, v10}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_8

    invoke-static {v5}, LN/v;->a(LN/v;)Z

    move-result v0

    if-eqz v0, :cond_7

    new-instance v0, LA0/c;

    invoke-direct {v0, v2, v5}, LA0/c;-><init>(ILjava/lang/Object;)V

    iget-object v2, v5, LN/v;->a:Lo0/r;

    invoke-virtual {v2, v0}, Lo0/r;->i(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :cond_8
    invoke-virtual {v8}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    move-result-object v11

    if-eq v11, v9, :cond_6

    goto :goto_3

    :cond_9
    const-string v0, "Unexpected notification"

    invoke-static {v0}, LD/d;->s(Ljava/lang/String;)V

    throw v3

    :pswitch_3
    move-object/from16 v0, p1

    check-cast v0, Ljava/util/Set;

    move-object/from16 v8, p2

    check-cast v8, LN/h;

    iget-object v8, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v8, LD/v0;

    iget-object v9, v8, LD/v0;->b:Ljava/lang/Object;

    monitor-enter v9

    :try_start_0
    iget-object v10, v8, LD/v0;->r:LB2/G;

    invoke-virtual {v10}, LB2/G;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, LD/o0;

    sget-object v11, LD/o0;->h:LD/o0;

    invoke-virtual {v10, v11}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v10

    if-ltz v10, :cond_11

    iget-object v3, v8, LD/v0;->g:Ln/B;

    instance-of v10, v0, LF/f;

    if-eqz v10, :cond_e

    check-cast v0, LF/f;

    iget-object v0, v0, LF/f;->d:Ln/B;

    iget-object v10, v0, Ln/B;->b:[Ljava/lang/Object;

    iget-object v0, v0, Ln/B;->a:[J

    array-length v11, v0

    sub-int/2addr v11, v4

    if-ltz v11, :cond_10

    move v4, v6

    :goto_5
    aget-wide v12, v0, v4

    not-long v14, v12

    shl-long/2addr v14, v2

    and-long/2addr v14, v12

    const-wide v16, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long v14, v14, v16

    cmp-long v14, v14, v16

    if-eqz v14, :cond_d

    sub-int v14, v4, v11

    not-int v14, v14

    ushr-int/lit8 v14, v14, 0x1f

    const/16 v15, 0x8

    rsub-int/lit8 v14, v14, 0x8

    move v2, v6

    :goto_6
    if-ge v2, v14, :cond_c

    const-wide/16 v17, 0xff

    and-long v17, v12, v17

    const-wide/16 v19, 0x80

    cmp-long v17, v17, v19

    if-gez v17, :cond_b

    shl-int/lit8 v17, v4, 0x3

    add-int v17, v17, v2

    aget-object v6, v10, v17

    instance-of v5, v6, LN/z;

    if-eqz v5, :cond_a

    move-object v5, v6

    check-cast v5, LN/z;

    invoke-virtual {v5, v7}, LN/z;->e(I)Z

    move-result v5

    if-nez v5, :cond_a

    goto :goto_7

    :catchall_0
    move-exception v0

    goto :goto_9

    :cond_a
    invoke-virtual {v3, v6}, Ln/B;->a(Ljava/lang/Object;)Z

    :cond_b
    :goto_7
    shr-long/2addr v12, v15

    add-int/2addr v2, v7

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_6

    :cond_c
    if-ne v14, v15, :cond_10

    :cond_d
    if-eq v4, v11, :cond_10

    add-int/2addr v4, v7

    const/4 v2, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_5

    :cond_e
    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_8
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_10

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    instance-of v4, v2, LN/z;

    if-eqz v4, :cond_f

    move-object v4, v2

    check-cast v4, LN/z;

    invoke-virtual {v4, v7}, LN/z;->e(I)Z

    move-result v4

    if-nez v4, :cond_f

    goto :goto_8

    :cond_f
    invoke-virtual {v3, v2}, Ln/B;->a(Ljava/lang/Object;)Z

    goto :goto_8

    :cond_10
    invoke-virtual {v8}, LD/v0;->e()Ly2/e;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_11
    monitor-exit v9

    if-eqz v3, :cond_12

    sget-object v0, Lc2/m;->a:Lc2/m;

    check-cast v3, Ly2/f;

    invoke-virtual {v3, v0}, Ly2/f;->t(Ljava/lang/Object;)V

    :cond_12
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :goto_9
    monitor-exit v9

    throw v0

    :pswitch_4
    move-object/from16 v0, p1

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    move-result v0

    move-object/from16 v2, p2

    check-cast v2, Lg2/g;

    invoke-interface {v2}, Lg2/g;->getKey()Lg2/h;

    move-result-object v4

    iget-object v5, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v5, LC2/u;

    iget-object v5, v5, LC2/u;->h:Lg2/i;

    invoke-interface {v5, v4}, Lg2/i;->n(Lg2/h;)Lg2/g;

    move-result-object v5

    sget-object v6, Ly2/s;->e:Ly2/s;

    if-eq v4, v6, :cond_14

    if-eq v2, v5, :cond_13

    const/high16 v0, -0x80000000

    goto :goto_a

    :cond_13
    add-int/2addr v0, v7

    :goto_a
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    goto :goto_f

    :cond_14
    check-cast v5, Ly2/S;

    check-cast v2, Ly2/S;

    :goto_b
    if-nez v2, :cond_15

    goto :goto_d

    :cond_15
    if-ne v2, v5, :cond_16

    :goto_c
    move-object v3, v2

    goto :goto_d

    :cond_16
    instance-of v4, v2, LD2/t;

    if-nez v4, :cond_19

    goto :goto_c

    :goto_d
    if-ne v3, v5, :cond_18

    if-nez v5, :cond_17

    goto :goto_e

    :cond_17
    add-int/2addr v0, v7

    :goto_e
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    :goto_f
    return-object v0

    :cond_18
    new-instance v0, Ljava/lang/IllegalStateException;

    new-instance v2, Ljava/lang/StringBuilder;

    const-string v4, "Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of "

    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, ", expected child of "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v3, ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use \'channelFlow\' builder instead of \'flow\'"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_19
    invoke-interface {v2}, Ly2/S;->getParent()Ly2/S;

    move-result-object v2

    goto :goto_b

    :pswitch_5
    move-object/from16 v0, p1

    check-cast v0, LD/n;

    move-object/from16 v2, p2

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    const/4 v3, 0x3

    and-int/2addr v2, v3

    if-ne v2, v4, :cond_1b

    invoke-virtual {v0}, LD/n;->y()Z

    move-result v2

    if-nez v2, :cond_1a

    goto :goto_10

    :cond_1a
    invoke-virtual {v0}, LD/n;->K()V

    goto :goto_11

    :cond_1b
    :goto_10
    iget-object v2, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v2, LA/P;

    iget-object v2, v2, LA/P;->j:Lv0/B;

    sget-object v3, LG1/c;->a:LL/a;

    const/4 v3, 0x0

    invoke-static {v2, v0, v3}, LA/O;->a(Lv0/B;LD/n;I)V

    :goto_11
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :pswitch_6
    move-object/from16 v2, p1

    check-cast v2, LD/n;

    move-object/from16 v3, p2

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    const/4 v5, 0x3

    and-int/2addr v3, v5

    if-ne v3, v4, :cond_1d

    invoke-virtual {v2}, LD/n;->y()Z

    move-result v3

    if-nez v3, :cond_1c

    goto :goto_12

    :cond_1c
    invoke-virtual {v2}, LD/n;->K()V

    goto :goto_14

    :cond_1d
    :goto_12
    sget-object v3, LP/i;->a:LP/i;

    sget-object v4, Lt/c;->a:Ls1/c;

    sget-object v4, LP/a;->o:LP/b;

    const/4 v5, 0x0

    invoke-static {v4, v2, v5}, Lt/j;->a(LP/b;LD/n;I)Lt/l;

    move-result-object v4

    iget v5, v2, LD/n;->M:I

    invoke-virtual {v2}, LD/n;->m()LD/j0;

    move-result-object v6

    invoke-static {v2, v3}, LP/m;->b(LD/n;LP/l;)LP/l;

    move-result-object v3

    sget-object v8, Ln0/f;->c:Ln0/e;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v8, Ln0/e;->b:Ln0/j;

    invoke-virtual {v2}, LD/n;->P()V

    iget-boolean v9, v2, LD/n;->L:Z

    if-eqz v9, :cond_1e

    invoke-virtual {v2, v8}, LD/n;->l(Ln0/j;)V

    goto :goto_13

    :cond_1e
    invoke-virtual {v2}, LD/n;->Y()V

    :goto_13
    sget-object v8, Ln0/e;->e:Ln0/d;

    invoke-static {v2, v4, v8}, LD/d;->G(LD/n;Ljava/lang/Object;Lo2/e;)V

    sget-object v4, Ln0/e;->d:Ln0/d;

    invoke-static {v2, v6, v4}, LD/d;->G(LD/n;Ljava/lang/Object;Lo2/e;)V

    sget-object v4, Ln0/e;->f:Ln0/d;

    iget-boolean v6, v2, LD/n;->L:Z

    if-nez v6, :cond_1f

    invoke-virtual {v2}, LD/n;->H()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v6, v8}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_20

    :cond_1f
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v2, v6}, LD/n;->V(Ljava/lang/Object;)V

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v2, v5, v4}, LD/n;->b(Ljava/lang/Object;Lo2/e;)V

    :cond_20
    sget-object v4, Ln0/e;->c:Ln0/d;

    invoke-static {v2, v3, v4}, LD/d;->G(LD/n;Ljava/lang/Object;Lo2/e;)V

    sget-object v3, Lt/m;->a:Lt/m;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    iget-object v4, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v4, LL/a;

    invoke-virtual {v4, v3, v2, v0}, LL/a;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/io/Serializable;)Ljava/lang/Object;

    invoke-virtual {v2, v7}, LD/n;->q(Z)V

    :goto_14
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :pswitch_7
    move-object/from16 v2, p1

    check-cast v2, LD/n;

    move-object/from16 v3, p2

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    const/4 v5, 0x3

    and-int/2addr v3, v5

    if-ne v3, v4, :cond_22

    invoke-virtual {v2}, LD/n;->y()Z

    move-result v3

    if-nez v3, :cond_21

    goto :goto_15

    :cond_21
    invoke-virtual {v2}, LD/n;->K()V

    goto/16 :goto_18

    :cond_22
    :goto_15
    sget v3, LA/c;->a:F

    sget v4, LA/c;->b:F

    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/b;->a(FF)LP/l;

    move-result-object v3

    iget-object v4, v1, LA/i;->f:Ljava/lang/Object;

    check-cast v4, Lt/p;

    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/b;->b(LP/l;Lt/p;)LP/l;

    move-result-object v3

    sget-object v4, Lt/c;->c:Lt/a;

    sget-object v5, LP/a;->n:LP/c;

    sget-object v6, Lt/s;->a:Lt/t;

    sget-object v6, Lt/c;->a:Ls1/c;

    invoke-static {v4, v6}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_23

    sget-object v6, LP/a;->m:LP/c;

    invoke-virtual {v5, v6}, LP/c;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_23

    const v4, -0x329d2765

    invoke-virtual {v2, v4}, LD/n;->N(I)V

    const/4 v4, 0x0

    invoke-virtual {v2, v4}, LD/n;->q(Z)V

    sget-object v4, Lt/s;->a:Lt/t;

    goto :goto_16

    :cond_23
    const v6, -0x329c60ae

    invoke-virtual {v2, v6}, LD/n;->N(I)V

    invoke-virtual {v2}, LD/n;->H()Ljava/lang/Object;

    move-result-object v6

    sget-object v8, LD/l;->a:LD/U;

    if-ne v6, v8, :cond_24

    new-instance v6, Lt/t;

    invoke-direct {v6, v4, v5}, Lt/t;-><init>(Lt/b;LP/c;)V

    invoke-virtual {v2, v6}, LD/n;->V(Ljava/lang/Object;)V

    :cond_24
    move-object v4, v6

    check-cast v4, Lt/t;

    const/4 v5, 0x0

    invoke-virtual {v2, v5}, LD/n;->q(Z)V

    :goto_16
    iget v5, v2, LD/n;->M:I

    invoke-virtual {v2}, LD/n;->m()LD/j0;

    move-result-object v6

    invoke-static {v2, v3}, LP/m;->b(LD/n;LP/l;)LP/l;

    move-result-object v3

    sget-object v8, Ln0/f;->c:Ln0/e;

    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    sget-object v8, Ln0/e;->b:Ln0/j;

    invoke-virtual {v2}, LD/n;->P()V

    iget-boolean v9, v2, LD/n;->L:Z

    if-eqz v9, :cond_25

    invoke-virtual {v2, v8}, LD/n;->l(Ln0/j;)V

    goto :goto_17

    :cond_25
    invoke-virtual {v2}, LD/n;->Y()V

    :goto_17
    sget-object v8, Ln0/e;->e:Ln0/d;

    invoke-static {v2, v4, v8}, LD/d;->G(LD/n;Ljava/lang/Object;Lo2/e;)V

    sget-object v4, Ln0/e;->d:Ln0/d;

    invoke-static {v2, v6, v4}, LD/d;->G(LD/n;Ljava/lang/Object;Lo2/e;)V

    sget-object v4, Ln0/e;->f:Ln0/d;

    iget-boolean v6, v2, LD/n;->L:Z

    if-nez v6, :cond_26

    invoke-virtual {v2}, LD/n;->H()Ljava/lang/Object;

    move-result-object v6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v6, v8}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_27

    :cond_26
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v2, v6}, LD/n;->V(Ljava/lang/Object;)V

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v2, v5, v4}, LD/n;->b(Ljava/lang/Object;Lo2/e;)V

    :cond_27
    sget-object v4, Ln0/e;->c:Ln0/d;

    invoke-static {v2, v3, v4}, LD/d;->G(LD/n;Ljava/lang/Object;Lo2/e;)V

    sget-object v3, Lt/u;->a:Lt/u;

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    sget-object v4, LG1/c;->c:LL/a;

    invoke-virtual {v4, v3, v2, v0}, LL/a;->a(Ljava/lang/Object;Ljava/lang/Object;Ljava/io/Serializable;)Ljava/lang/Object;

    invoke-virtual {v2, v7}, LD/n;->q(Z)V

    :goto_18
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
