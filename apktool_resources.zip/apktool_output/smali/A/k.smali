.class public final LA/k;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# instance fields
.field public final synthetic e:LA0/c;

.field public final synthetic f:LP/l;

.field public final synthetic g:Z

.field public final synthetic h:LW/H;

.field public final synthetic i:LA/b;

.field public final synthetic j:LA/g;

.field public final synthetic k:Lt/p;

.field public final synthetic l:Ls/g;

.field public final synthetic m:I


# direct methods
.method public constructor <init>(LA0/c;LP/l;ZLW/H;LA/b;LA/g;Lt/p;Ls/g;I)V
    .locals 1

    sget-object v0, LG1/c;->a:LL/a;

    iput-object p1, p0, LA/k;->e:LA0/c;

    iput-object p2, p0, LA/k;->f:LP/l;

    iput-boolean p3, p0, LA/k;->g:Z

    iput-object p4, p0, LA/k;->h:LW/H;

    iput-object p5, p0, LA/k;->i:LA/b;

    iput-object p6, p0, LA/k;->j:LA/g;

    iput-object p7, p0, LA/k;->k:Lt/p;

    iput-object p8, p0, LA/k;->l:Ls/g;

    iput p9, p0, LA/k;->m:I

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    move-object v8, p1

    check-cast v8, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    iget p1, p0, LA/k;->m:I

    or-int/lit8 p1, p1, 0x1

    invoke-static {p1}, LD/d;->J(I)I

    move-result v9

    sget-object p1, LG1/c;->a:LL/a;

    iget-object v0, p0, LA/k;->e:LA0/c;

    iget-object v5, p0, LA/k;->j:LA/g;

    iget-object v6, p0, LA/k;->k:Lt/p;

    iget-object v1, p0, LA/k;->f:LP/l;

    iget-boolean v2, p0, LA/k;->g:Z

    iget-object v3, p0, LA/k;->h:LW/H;

    iget-object v4, p0, LA/k;->i:LA/b;

    iget-object v7, p0, LA/k;->l:Ls/g;

    invoke-static/range {v0 .. v9}, LA/C;->a(LA0/c;LP/l;ZLW/H;LA/b;LA/g;Lt/p;Ls/g;LD/n;I)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1
.end method
