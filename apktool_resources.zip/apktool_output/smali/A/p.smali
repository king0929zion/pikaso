.class public final LA/p;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/a;


# static fields
.field public static final f:LA/p;

.field public static final g:LA/p;

.field public static final h:LA/p;

.field public static final i:LA/p;

.field public static final j:LA/p;

.field public static final k:LA/p;

.field public static final l:LA/p;

.field public static final m:LA/p;

.field public static final n:LA/p;

.field public static final o:LA/p;

.field public static final p:LA/p;

.field public static final q:LA/p;


# instance fields
.field public final synthetic e:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->f:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->g:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->h:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->i:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->j:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->k:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->l:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->m:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/16 v2, 0x8

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->n:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/16 v2, 0x9

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->o:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/16 v2, 0xa

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->p:LA/p;

    new-instance v0, LA/p;

    const/4 v1, 0x0

    const/16 v2, 0xb

    invoke-direct {v0, v1, v2}, LA/p;-><init>(II)V

    sput-object v0, LA/p;->q:LA/p;

    return-void
.end method

.method public synthetic constructor <init>(II)V
    .locals 0

    iput p2, p0, LA/p;->e:I

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final c()Ljava/lang/Object;
    .locals 75

    move-object/from16 v0, p0

    iget v1, v0, LA/p;->e:I

    packed-switch v1, :pswitch_data_0

    new-instance v1, LA/P;

    invoke-direct {v1}, LA/P;-><init>()V

    return-object v1

    :pswitch_0
    sget-object v1, LC/j;->a:Lv0/B;

    return-object v1

    :pswitch_1
    const/4 v1, 0x0

    int-to-float v1, v1

    new-instance v2, LG0/e;

    invoke-direct {v2, v1}, LG0/e;-><init>(F)V

    return-object v2

    :pswitch_2
    new-instance v1, LA/G;

    invoke-direct {v1}, LA/G;-><init>()V

    return-object v1

    :pswitch_3
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object v1

    :pswitch_4
    new-instance v1, LA/B;

    invoke-direct {v1}, LA/B;-><init>()V

    return-object v1

    :pswitch_5
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    return-object v1

    :pswitch_6
    const/16 v1, 0x30

    int-to-float v1, v1

    new-instance v2, LG0/e;

    invoke-direct {v2, v1}, LG0/e;-><init>(F)V

    return-object v2

    :pswitch_7
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object v1

    :pswitch_8
    sget-wide v1, LW/r;->b:J

    new-instance v3, LW/r;

    invoke-direct {v3, v1, v2}, LW/r;-><init>(J)V

    return-object v3

    :pswitch_9
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object v1

    :pswitch_a
    sget-object v1, LA/q;->a:LD/M0;

    sget-wide v41, LC/a;->t:J

    sget-wide v5, LC/a;->j:J

    sget-wide v7, LC/a;->u:J

    sget-wide v9, LC/a;->k:J

    sget-wide v11, LC/a;->e:J

    sget-wide v13, LC/a;->w:J

    sget-wide v15, LC/a;->l:J

    sget-wide v17, LC/a;->x:J

    sget-wide v19, LC/a;->m:J

    sget-wide v21, LC/a;->H:J

    sget-wide v23, LC/a;->p:J

    sget-wide v25, LC/a;->I:J

    sget-wide v27, LC/a;->q:J

    sget-wide v29, LC/a;->a:J

    sget-wide v31, LC/a;->g:J

    sget-wide v33, LC/a;->y:J

    sget-wide v35, LC/a;->n:J

    sget-wide v37, LC/a;->G:J

    sget-wide v39, LC/a;->o:J

    sget-wide v43, LC/a;->f:J

    sget-wide v45, LC/a;->d:J

    sget-wide v47, LC/a;->b:J

    sget-wide v49, LC/a;->h:J

    sget-wide v51, LC/a;->c:J

    sget-wide v53, LC/a;->i:J

    sget-wide v55, LC/a;->r:J

    sget-wide v57, LC/a;->s:J

    sget-wide v59, LC/a;->v:J

    sget-wide v61, LC/a;->z:J

    sget-wide v65, LC/a;->A:J

    sget-wide v67, LC/a;->B:J

    sget-wide v69, LC/a;->C:J

    sget-wide v71, LC/a;->D:J

    sget-wide v73, LC/a;->E:J

    sget-wide v63, LC/a;->F:J

    new-instance v1, LA/o;

    move-object v2, v1

    move-wide/from16 v3, v41

    invoke-direct/range {v2 .. v74}, LA/o;-><init>(JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ)V

    return-object v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
