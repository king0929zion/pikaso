.class public final LA/j;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# instance fields
.field public final synthetic e:J

.field public final synthetic f:Lt/p;


# direct methods
.method public constructor <init>(JLt/p;)V
    .locals 1

    sget-object v0, LG1/c;->a:LL/a;

    iput-wide p1, p0, LA/j;->e:J

    iput-object p3, p0, LA/j;->f:Lt/p;

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    move-object v4, p1

    check-cast v4, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    move-result p1

    and-int/lit8 p1, p1, 0x3

    const/4 p2, 0x2

    if-ne p1, p2, :cond_1

    invoke-virtual {v4}, LD/n;->y()Z

    move-result p1

    if-nez p1, :cond_0

    goto :goto_0

    :cond_0
    invoke-virtual {v4}, LD/n;->K()V

    goto :goto_1

    :cond_1
    :goto_0
    sget-object p1, LA/Q;->a:LD/M0;

    invoke-virtual {v4, p1}, LD/n;->k(LD/k0;)Ljava/lang/Object;

    move-result-object p1

    check-cast p1, LA/P;

    iget-object v2, p1, LA/P;->m:Lv0/B;

    new-instance p1, LA/i;

    sget-object p2, LG1/c;->a:LL/a;

    iget-object p2, p0, LA/j;->f:Lt/p;

    invoke-direct {p1, p2}, LA/i;-><init>(Lt/p;)V

    const p2, 0x4f204156

    invoke-static {p2, p1, v4}, LL/b;->b(ILp2/h;LD/n;)LL/a;

    move-result-object v3

    const/16 v5, 0x180

    iget-wide v0, p0, LA/j;->e:J

    invoke-static/range {v0 .. v5}, LB/a;->a(JLv0/B;LL/a;LD/n;I)V

    :goto_1
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1
.end method
