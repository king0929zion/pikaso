.class public final LA/n;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# instance fields
.field public final synthetic e:LP/l;

.field public final synthetic f:LW/H;

.field public final synthetic g:LA/l;

.field public final synthetic h:LA/m;

.field public final synthetic i:LL/a;

.field public final synthetic j:I


# direct methods
.method public constructor <init>(LP/l;LW/H;LA/l;LA/m;LL/a;I)V
    .locals 0

    iput-object p1, p0, LA/n;->e:LP/l;

    iput-object p2, p0, LA/n;->f:LW/H;

    iput-object p3, p0, LA/n;->g:LA/l;

    iput-object p4, p0, LA/n;->h:LA/m;

    iput-object p5, p0, LA/n;->i:LL/a;

    iput p6, p0, LA/n;->j:I

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    move-object v5, p1

    check-cast v5, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    iget p1, p0, LA/n;->j:I

    or-int/lit8 p1, p1, 0x1

    invoke-static {p1}, LD/d;->J(I)I

    move-result v6

    iget-object v4, p0, LA/n;->i:LL/a;

    iget-object v2, p0, LA/n;->g:LA/l;

    iget-object v3, p0, LA/n;->h:LA/m;

    iget-object v0, p0, LA/n;->e:LP/l;

    iget-object v1, p0, LA/n;->f:LW/H;

    invoke-static/range {v0 .. v6}, LA/C;->b(LP/l;LW/H;LA/l;LA/m;LL/a;LD/n;I)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1
.end method
