.class public abstract LA/q;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD/M0;

.field public static final b:LD/M0;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    sget-object v0, LA/p;->f:LA/p;

    new-instance v1, LD/M0;

    invoke-direct {v1, v0}, LD/k0;-><init>(Lo2/a;)V

    sput-object v1, LA/q;->a:LD/M0;

    sget-object v0, LA/p;->g:LA/p;

    new-instance v1, LD/M0;

    invoke-direct {v1, v0}, LD/k0;-><init>(Lo2/a;)V

    sput-object v1, LA/q;->b:LD/M0;

    return-void
.end method

.method public static final a(LA/o;J)J
    .locals 5

    iget-wide v0, p0, LA/o;->a:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-wide p0, p0, LA/o;->b:J

    goto/16 :goto_1

    :cond_0
    iget-wide v0, p0, LA/o;->f:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_1

    iget-wide p0, p0, LA/o;->g:J

    goto/16 :goto_1

    :cond_1
    iget-wide v0, p0, LA/o;->j:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_2

    iget-wide p0, p0, LA/o;->k:J

    goto/16 :goto_1

    :cond_2
    iget-wide v0, p0, LA/o;->n:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-wide p0, p0, LA/o;->o:J

    goto/16 :goto_1

    :cond_3
    iget-wide v0, p0, LA/o;->w:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_4

    iget-wide p0, p0, LA/o;->x:J

    goto/16 :goto_1

    :cond_4
    iget-wide v0, p0, LA/o;->c:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_5

    iget-wide p0, p0, LA/o;->d:J

    goto/16 :goto_1

    :cond_5
    iget-wide v0, p0, LA/o;->h:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_6

    iget-wide p0, p0, LA/o;->i:J

    goto/16 :goto_1

    :cond_6
    iget-wide v0, p0, LA/o;->l:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_7

    iget-wide p0, p0, LA/o;->m:J

    goto/16 :goto_1

    :cond_7
    iget-wide v0, p0, LA/o;->y:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-wide p0, p0, LA/o;->z:J

    goto :goto_1

    :cond_8
    iget-wide v0, p0, LA/o;->u:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_9

    iget-wide p0, p0, LA/o;->v:J

    goto :goto_1

    :cond_9
    iget-wide v0, p0, LA/o;->p:J

    invoke-static {p1, p2, v0, v1}, LW/r;->c(JJ)Z

    move-result v0

    iget-wide v1, p0, LA/o;->q:J

    if-eqz v0, :cond_a

    :goto_0
    move-wide p0, v1

    goto :goto_1

    :cond_a
    iget-wide v3, p0, LA/o;->r:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_b

    iget-wide p0, p0, LA/o;->s:J

    goto :goto_1

    :cond_b
    iget-wide v3, p0, LA/o;->D:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_c

    goto :goto_0

    :cond_c
    iget-wide v3, p0, LA/o;->F:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_d

    goto :goto_0

    :cond_d
    iget-wide v3, p0, LA/o;->G:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_e

    goto :goto_0

    :cond_e
    iget-wide v3, p0, LA/o;->H:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_f

    goto :goto_0

    :cond_f
    iget-wide v3, p0, LA/o;->I:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result v0

    if-eqz v0, :cond_10

    goto :goto_0

    :cond_10
    iget-wide v3, p0, LA/o;->J:J

    invoke-static {p1, p2, v3, v4}, LW/r;->c(JJ)Z

    move-result p0

    if-eqz p0, :cond_11

    goto :goto_0

    :cond_11
    sget p0, LW/r;->g:I

    sget-wide p0, LW/r;->f:J

    :goto_1
    return-wide p0
.end method

.method public static final b(LA/o;I)J
    .locals 0

    invoke-static {p1}, Lp/f;->b(I)I

    move-result p1

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    sget-wide p0, LW/r;->f:J

    goto/16 :goto_0

    :pswitch_1
    iget-wide p0, p0, LA/o;->l:J

    goto/16 :goto_0

    :pswitch_2
    iget-wide p0, p0, LA/o;->j:J

    goto/16 :goto_0

    :pswitch_3
    iget-wide p0, p0, LA/o;->r:J

    goto/16 :goto_0

    :pswitch_4
    iget-wide p0, p0, LA/o;->t:J

    goto/16 :goto_0

    :pswitch_5
    iget-wide p0, p0, LA/o;->E:J

    goto/16 :goto_0

    :pswitch_6
    iget-wide p0, p0, LA/o;->J:J

    goto/16 :goto_0

    :pswitch_7
    iget-wide p0, p0, LA/o;->I:J

    goto/16 :goto_0

    :pswitch_8
    iget-wide p0, p0, LA/o;->H:J

    goto/16 :goto_0

    :pswitch_9
    iget-wide p0, p0, LA/o;->G:J

    goto/16 :goto_0

    :pswitch_a
    iget-wide p0, p0, LA/o;->F:J

    goto/16 :goto_0

    :pswitch_b
    iget-wide p0, p0, LA/o;->D:J

    goto :goto_0

    :pswitch_c
    iget-wide p0, p0, LA/o;->p:J

    goto :goto_0

    :pswitch_d
    iget-wide p0, p0, LA/o;->h:J

    goto :goto_0

    :pswitch_e
    iget-wide p0, p0, LA/o;->f:J

    goto :goto_0

    :pswitch_f
    iget-wide p0, p0, LA/o;->C:J

    goto :goto_0

    :pswitch_10
    iget-wide p0, p0, LA/o;->c:J

    goto :goto_0

    :pswitch_11
    iget-wide p0, p0, LA/o;->a:J

    goto :goto_0

    :pswitch_12
    iget-wide p0, p0, LA/o;->B:J

    goto :goto_0

    :pswitch_13
    iget-wide p0, p0, LA/o;->A:J

    goto :goto_0

    :pswitch_14
    iget-wide p0, p0, LA/o;->m:J

    goto :goto_0

    :pswitch_15
    iget-wide p0, p0, LA/o;->k:J

    goto :goto_0

    :pswitch_16
    iget-wide p0, p0, LA/o;->s:J

    goto :goto_0

    :pswitch_17
    iget-wide p0, p0, LA/o;->q:J

    goto :goto_0

    :pswitch_18
    iget-wide p0, p0, LA/o;->i:J

    goto :goto_0

    :pswitch_19
    iget-wide p0, p0, LA/o;->g:J

    goto :goto_0

    :pswitch_1a
    iget-wide p0, p0, LA/o;->d:J

    goto :goto_0

    :pswitch_1b
    iget-wide p0, p0, LA/o;->b:J

    goto :goto_0

    :pswitch_1c
    iget-wide p0, p0, LA/o;->z:J

    goto :goto_0

    :pswitch_1d
    iget-wide p0, p0, LA/o;->x:J

    goto :goto_0

    :pswitch_1e
    iget-wide p0, p0, LA/o;->o:J

    goto :goto_0

    :pswitch_1f
    iget-wide p0, p0, LA/o;->u:J

    goto :goto_0

    :pswitch_20
    iget-wide p0, p0, LA/o;->e:J

    goto :goto_0

    :pswitch_21
    iget-wide p0, p0, LA/o;->v:J

    goto :goto_0

    :pswitch_22
    iget-wide p0, p0, LA/o;->y:J

    goto :goto_0

    :pswitch_23
    iget-wide p0, p0, LA/o;->w:J

    goto :goto_0

    :pswitch_24
    iget-wide p0, p0, LA/o;->n:J

    :goto_0
    return-wide p0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_24
        :pswitch_23
        :pswitch_22
        :pswitch_21
        :pswitch_20
        :pswitch_1f
        :pswitch_1e
        :pswitch_1d
        :pswitch_1c
        :pswitch_1b
        :pswitch_1a
        :pswitch_0
        :pswitch_0
        :pswitch_19
        :pswitch_18
        :pswitch_0
        :pswitch_0
        :pswitch_17
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_0
        :pswitch_0
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_0
        :pswitch_0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_0
        :pswitch_0
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method
