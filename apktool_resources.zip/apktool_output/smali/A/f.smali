.class public final LA/f;
.super Li2/j;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# instance fields
.field public h:I

.field public final synthetic i:Lp/d;

.field public final synthetic j:F

.field public final synthetic k:Z

.field public final synthetic l:LA/g;

.field public final synthetic m:Ls/f;


# direct methods
.method public constructor <init>(Lp/d;FZLA/g;Ls/f;Lg2/d;)V
    .locals 0

    iput-object p1, p0, LA/f;->i:Lp/d;

    iput p2, p0, LA/f;->j:F

    iput-boolean p3, p0, LA/f;->k:Z

    iput-object p4, p0, LA/f;->l:LA/g;

    iput-object p5, p0, LA/f;->m:Ls/f;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p6}, Li2/j;-><init>(ILg2/d;)V

    return-void
.end method


# virtual methods
.method public final f(Lg2/d;Ljava/lang/Object;)Lg2/d;
    .locals 7

    new-instance p2, LA/f;

    iget-object v4, p0, LA/f;->l:LA/g;

    iget-object v5, p0, LA/f;->m:Ls/f;

    iget-object v1, p0, LA/f;->i:Lp/d;

    iget v2, p0, LA/f;->j:F

    iget-boolean v3, p0, LA/f;->k:Z

    move-object v0, p2

    move-object v6, p1

    invoke-direct/range {v0 .. v6}, LA/f;-><init>(Lp/d;FZLA/g;Ls/f;Lg2/d;)V

    return-object p2
.end method

.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    check-cast p1, Ly2/u;

    check-cast p2, Lg2/d;

    invoke-virtual {p0, p2, p1}, LA/f;->f(Lg2/d;Ljava/lang/Object;)Lg2/d;

    move-result-object p1

    check-cast p1, LA/f;

    sget-object p2, Lc2/m;->a:Lc2/m;

    invoke-virtual {p1, p2}, LA/f;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    sget-object v0, Lh2/a;->d:Lh2/a;

    iget v1, p0, LA/f;->h:I

    sget-object v2, Lc2/m;->a:Lc2/m;

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    if-eq v1, v4, :cond_1

    if-ne v1, v3, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    :goto_0
    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    goto/16 :goto_5

    :cond_2
    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    iget-object p1, p0, LA/f;->i:Lp/d;

    iget-object v1, p1, Lp/d;->e:LD/f0;

    invoke-virtual {v1}, LD/f0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LG0/e;

    iget v1, v1, LG0/e;->d:F

    iget v5, p0, LA/f;->j:F

    invoke-static {v1, v5}, LG0/e;->a(FF)Z

    move-result v1

    if-nez v1, :cond_11

    iget-boolean v1, p0, LA/f;->k:Z

    if-nez v1, :cond_3

    new-instance v1, LG0/e;

    invoke-direct {v1, v5}, LG0/e;-><init>(F)V

    iput v4, p0, LA/f;->h:I

    invoke-virtual {p1, v1, p0}, Lp/d;->d(LG0/e;Li2/j;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_11

    return-object v0

    :cond_3
    iget-object v1, p1, Lp/d;->e:LD/f0;

    invoke-virtual {v1}, LD/f0;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LG0/e;

    iget v1, v1, LG0/e;->d:F

    iget-object v4, p0, LA/f;->l:LA/g;

    iget v6, v4, LA/g;->b:F

    invoke-static {v1, v6}, LG0/e;->a(FF)Z

    move-result v6

    const/4 v7, 0x0

    if-eqz v6, :cond_4

    new-instance v1, Ls/i;

    const-wide/16 v8, 0x0

    invoke-direct {v1, v8, v9}, Ls/i;-><init>(J)V

    goto :goto_1

    :cond_4
    iget v6, v4, LA/g;->d:F

    invoke-static {v1, v6}, LG0/e;->a(FF)Z

    move-result v6

    if-eqz v6, :cond_5

    new-instance v1, Ls/d;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    goto :goto_1

    :cond_5
    iget v4, v4, LA/g;->c:F

    invoke-static {v1, v4}, LG0/e;->a(FF)Z

    move-result v1

    if-eqz v1, :cond_6

    new-instance v1, Ls/b;

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    goto :goto_1

    :cond_6
    move-object v1, v7

    :goto_1
    iput v3, p0, LA/f;->h:I

    sget-object v3, LB/b;->a:Lp/G;

    iget-object v3, p0, LA/f;->m:Ls/f;

    if-eqz v3, :cond_a

    instance-of v1, v3, Ls/i;

    sget-object v4, LB/b;->a:Lp/G;

    if-eqz v1, :cond_7

    :goto_2
    move-object v7, v4

    goto :goto_3

    :cond_7
    instance-of v1, v3, Ls/a;

    if-eqz v1, :cond_8

    goto :goto_2

    :cond_8
    instance-of v1, v3, Ls/d;

    if-eqz v1, :cond_9

    goto :goto_2

    :cond_9
    instance-of v1, v3, Ls/b;

    if-eqz v1, :cond_e

    goto :goto_2

    :cond_a
    if-eqz v1, :cond_e

    instance-of v3, v1, Ls/i;

    sget-object v4, LB/b;->b:Lp/G;

    if-eqz v3, :cond_b

    goto :goto_2

    :cond_b
    instance-of v3, v1, Ls/a;

    if-eqz v3, :cond_c

    goto :goto_2

    :cond_c
    instance-of v3, v1, Ls/d;

    if-eqz v3, :cond_d

    sget-object v7, LB/b;->c:Lp/G;

    goto :goto_3

    :cond_d
    instance-of v1, v1, Ls/b;

    if-eqz v1, :cond_e

    goto :goto_2

    :cond_e
    :goto_3
    if-eqz v7, :cond_10

    new-instance v1, LG0/e;

    invoke-direct {v1, v5}, LG0/e;-><init>(F)V

    invoke-static {p1, v1, v7, p0}, Lp/d;->b(Lp/d;Ljava/lang/Comparable;Lp/G;Li2/j;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_f

    goto :goto_4

    :cond_f
    move-object p1, v2

    goto :goto_4

    :cond_10
    new-instance v1, LG0/e;

    invoke-direct {v1, v5}, LG0/e;-><init>(F)V

    invoke-virtual {p1, v1, p0}, Lp/d;->d(LG0/e;Li2/j;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_f

    :goto_4
    if-ne p1, v0, :cond_11

    return-object v0

    :cond_11
    :goto_5
    return-object v2
.end method
