.class public final LA/h;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/c;


# static fields
.field public static final f:LA/h;

.field public static final g:LA/h;


# instance fields
.field public final synthetic e:I


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    new-instance v0, LA/h;

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, LA/h;-><init>(II)V

    sput-object v0, LA/h;->f:LA/h;

    new-instance v0, LA/h;

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, LA/h;-><init>(II)V

    sput-object v0, LA/h;->g:LA/h;

    return-void
.end method

.method public synthetic constructor <init>(II)V
    .locals 0

    iput p2, p0, LA/h;->e:I

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    sget-object v0, Lc2/m;->a:Lc2/m;

    iget v1, p0, LA/h;->e:I

    packed-switch v1, :pswitch_data_0

    check-cast p1, Lt0/g;

    sget-object v1, Lt0/p;->a:[Lv2/c;

    sget-object v1, Lt0/n;->l:Lt0/q;

    sget-object v2, Lt0/p;->a:[Lv2/c;

    const/4 v3, 0x5

    aget-object v2, v2, v3

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v1, v2}, Lt0/g;->b(Lt0/q;Ljava/lang/Object;)V

    return-object v0

    :pswitch_0
    check-cast p1, Lt0/g;

    const/4 v1, 0x0

    invoke-static {p1, v1}, Lt0/p;->c(Lt0/g;I)V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
