.class public final LB2/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB2/e;


# instance fields
.field public final d:LB2/e;


# direct methods
.method public constructor <init>(LB2/e;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB2/d;->d:LB2/e;

    return-void
.end method


# virtual methods
.method public final o(LB2/f;Lg2/d;)Ljava/lang/Object;
    .locals 2

    new-instance v0, Lp2/o;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sget-object v1, LC2/c;->b:LD2/w;

    iput-object v1, v0, Lp2/o;->d:Ljava/lang/Object;

    new-instance v1, LB2/c;

    invoke-direct {v1, p0, v0, p1}, LB2/c;-><init>(LB2/d;Lp2/o;LB2/f;)V

    iget-object p1, p0, LB2/d;->d:LB2/e;

    invoke-interface {p1, v1, p2}, LB2/e;->o(LB2/f;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, Lh2/a;->d:Lh2/a;

    if-ne p1, p2, :cond_0

    return-object p1

    :cond_0
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1
.end method
