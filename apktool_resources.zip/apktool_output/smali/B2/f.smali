.class public interface abstract LB2/f;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;
.end method
