.class public final LB2/B;
.super Li2/j;
.source "SourceFile"

# interfaces
.implements Lo2/f;


# instance fields
.field public h:I

.field public synthetic i:LB2/f;

.field public synthetic j:I

.field public final synthetic k:LB2/D;


# direct methods
.method public constructor <init>(LB2/D;Lg2/d;)V
    .locals 0

    iput-object p1, p0, LB2/B;->k:LB2/D;

    const/4 p1, 0x3

    invoke-direct {p0, p1, p2}, Li2/j;-><init>(ILg2/d;)V

    return-void
.end method


# virtual methods
.method public final a(Ljava/lang/Object;Ljava/lang/Object;Ljava/io/Serializable;)Ljava/lang/Object;
    .locals 2

    check-cast p1, LB2/f;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    move-result p2

    check-cast p3, Lg2/d;

    new-instance v0, LB2/B;

    iget-object v1, p0, LB2/B;->k:LB2/D;

    invoke-direct {v0, v1, p3}, LB2/B;-><init>(LB2/D;Lg2/d;)V

    iput-object p1, v0, LB2/B;->i:LB2/f;

    iput p2, v0, LB2/B;->j:I

    sget-object p1, Lc2/m;->a:Lc2/m;

    invoke-virtual {v0, p1}, LB2/B;->l(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    sget-object v0, Lh2/a;->d:Lh2/a;

    iget v1, p0, LB2/B;->h:I

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v7, p0, LB2/B;->k:LB2/D;

    if-eqz v1, :cond_5

    if-eq v1, v6, :cond_4

    if-eq v1, v5, :cond_3

    if-eq v1, v4, :cond_2

    if-eq v1, v3, :cond_1

    if-ne v1, v2, :cond_0

    goto :goto_0

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_1
    iget-object v1, p0, LB2/B;->i:LB2/f;

    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_3

    :cond_2
    iget-object v1, p0, LB2/B;->i:LB2/f;

    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_2

    :cond_3
    iget-object v1, p0, LB2/B;->i:LB2/f;

    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_1

    :cond_4
    :goto_0
    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_4

    :cond_5
    invoke-static {p1}, LZ0/d;->U(Ljava/lang/Object;)V

    iget-object v1, p0, LB2/B;->i:LB2/f;

    iget p1, p0, LB2/B;->j:I

    if-lez p1, :cond_6

    sget-object p1, LB2/y;->d:LB2/y;

    iput v6, p0, LB2/B;->h:I

    invoke-interface {v1, p1, p0}, LB2/f;->b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_a

    return-object v0

    :cond_6
    iget-wide v8, v7, LB2/D;->a:J

    iput-object v1, p0, LB2/B;->i:LB2/f;

    iput v5, p0, LB2/B;->h:I

    invoke-static {v8, v9, p0}, Ly2/v;->c(JLi2/c;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_7

    return-object v0

    :cond_7
    :goto_1
    iget-wide v5, v7, LB2/D;->b:J

    const-wide/16 v8, 0x0

    cmp-long p1, v5, v8

    if-lez p1, :cond_9

    sget-object p1, LB2/y;->e:LB2/y;

    iput-object v1, p0, LB2/B;->i:LB2/f;

    iput v4, p0, LB2/B;->h:I

    invoke-interface {v1, p1, p0}, LB2/f;->b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_8

    return-object v0

    :cond_8
    :goto_2
    iget-wide v4, v7, LB2/D;->b:J

    iput-object v1, p0, LB2/B;->i:LB2/f;

    iput v3, p0, LB2/B;->h:I

    invoke-static {v4, v5, p0}, Ly2/v;->c(JLi2/c;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_9

    return-object v0

    :cond_9
    :goto_3
    sget-object p1, LB2/y;->f:LB2/y;

    const/4 v3, 0x0

    iput-object v3, p0, LB2/B;->i:LB2/f;

    iput v2, p0, LB2/B;->h:I

    invoke-interface {v1, p1, p0}, LB2/f;->b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_a

    return-object v0

    :cond_a
    :goto_4
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1
.end method
