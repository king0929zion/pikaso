.class public final LB2/h;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# static fields
.field public static final e:LB2/h;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LB2/h;

    const/4 v1, 0x2

    invoke-direct {v0, v1}, Lp2/h;-><init>(I)V

    sput-object v0, LB2/h;->e:LB2/h;

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    invoke-static {p1, p2}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    return-object p1
.end method
