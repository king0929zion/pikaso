.class public final LB2/a;
.super Li2/c;
.source "SourceFile"


# instance fields
.field public g:LC2/u;

.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:LA/t;

.field public j:I


# direct methods
.method public constructor <init>(LA/t;Lg2/d;)V
    .locals 0

    iput-object p1, p0, LB2/a;->i:LA/t;

    invoke-direct {p0, p2}, Li2/c;-><init>(Lg2/d;)V

    return-void
.end method


# virtual methods
.method public final l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, LB2/a;->h:Ljava/lang/Object;

    iget p1, p0, LB2/a;->j:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB2/a;->j:I

    iget-object p1, p0, LB2/a;->i:LA/t;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, LA/t;->o(LB2/f;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
