.class public final LB2/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LB2/f;


# instance fields
.field public final synthetic d:I

.field public final e:Ljava/lang/Object;

.field public final f:Ljava/lang/Object;

.field public final g:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LB2/d;Lp2/o;LB2/f;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LB2/c;->d:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB2/c;->f:Ljava/lang/Object;

    iput-object p2, p0, LB2/c;->g:Ljava/lang/Object;

    iput-object p3, p0, LB2/c;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(LB2/f;Lg2/i;)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LB2/c;->d:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p2, p0, LB2/c;->f:Ljava/lang/Object;

    .line 5
    invoke-static {p2}, LD2/a;->l(Lg2/i;)Ljava/lang/Object;

    move-result-object p2

    iput-object p2, p0, LB2/c;->g:Ljava/lang/Object;

    .line 6
    new-instance p2, LC2/A;

    const/4 v0, 0x0

    invoke-direct {p2, p1, v0}, LC2/A;-><init>(LB2/f;Lg2/d;)V

    iput-object p2, p0, LB2/c;->e:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lp2/m;LB2/f;LB2/C;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LB2/c;->d:I

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LB2/c;->f:Ljava/lang/Object;

    iput-object p2, p0, LB2/c;->e:Ljava/lang/Object;

    iput-object p3, p0, LB2/c;->g:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;
    .locals 7

    iget v0, p0, LB2/c;->d:I

    packed-switch v0, :pswitch_data_0

    iget-object v0, p0, LB2/c;->f:Ljava/lang/Object;

    check-cast v0, Lg2/i;

    iget-object v1, p0, LB2/c;->g:Ljava/lang/Object;

    iget-object v2, p0, LB2/c;->e:Ljava/lang/Object;

    check-cast v2, LC2/A;

    invoke-static {v0, p1, v1, v2, p2}, LC2/c;->a(Lg2/i;Ljava/lang/Object;Ljava/lang/Object;Lo2/e;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    sget-object p2, Lh2/a;->d:Lh2/a;

    if-ne p1, p2, :cond_0

    goto :goto_0

    :cond_0
    sget-object p1, Lc2/m;->a:Lc2/m;

    :goto_0
    return-object p1

    :pswitch_0
    instance-of v0, p2, LB2/j;

    if-eqz v0, :cond_1

    move-object v0, p2

    check-cast v0, LB2/j;

    iget v1, v0, LB2/j;->k:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_1

    sub-int/2addr v1, v2

    iput v1, v0, LB2/j;->k:I

    goto :goto_1

    :cond_1
    new-instance v0, LB2/j;

    invoke-direct {v0, p0, p2}, LB2/j;-><init>(LB2/c;Lg2/d;)V

    :goto_1
    iget-object p2, v0, LB2/j;->i:Ljava/lang/Object;

    sget-object v1, Lh2/a;->d:Lh2/a;

    iget v2, v0, LB2/j;->k:I

    sget-object v3, Lc2/m;->a:Lc2/m;

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v2, :cond_5

    if-eq v2, v6, :cond_4

    if-eq v2, v5, :cond_3

    if-ne v2, v4, :cond_2

    goto :goto_2

    :cond_2
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_3
    iget-object p1, v0, LB2/j;->h:Ljava/lang/Object;

    iget-object v2, v0, LB2/j;->g:LB2/c;

    invoke-static {p2}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_4

    :cond_4
    :goto_2
    invoke-static {p2}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_3

    :cond_5
    invoke-static {p2}, LZ0/d;->U(Ljava/lang/Object;)V

    iget-object p2, p0, LB2/c;->f:Ljava/lang/Object;

    check-cast p2, Lp2/m;

    iget-boolean p2, p2, Lp2/m;->d:Z

    if-eqz p2, :cond_7

    iput v6, v0, LB2/j;->k:I

    iget-object p2, p0, LB2/c;->e:Ljava/lang/Object;

    check-cast p2, LB2/f;

    invoke-interface {p2, p1, v0}, LB2/f;->b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_6

    goto :goto_5

    :cond_6
    :goto_3
    move-object v1, v3

    goto :goto_5

    :cond_7
    iput-object p0, v0, LB2/j;->g:LB2/c;

    iput-object p1, v0, LB2/j;->h:Ljava/lang/Object;

    iput v5, v0, LB2/j;->k:I

    iget-object p2, p0, LB2/c;->g:Ljava/lang/Object;

    check-cast p2, LB2/C;

    invoke-virtual {p2, p1, v0}, LB2/C;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    if-ne p2, v1, :cond_8

    goto :goto_5

    :cond_8
    move-object v2, p0

    :goto_4
    check-cast p2, Ljava/lang/Boolean;

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p2

    if-nez p2, :cond_6

    iget-object p2, v2, LB2/c;->f:Ljava/lang/Object;

    check-cast p2, Lp2/m;

    iput-boolean v6, p2, Lp2/m;->d:Z

    const/4 p2, 0x0

    iput-object p2, v0, LB2/j;->g:LB2/c;

    iput-object p2, v0, LB2/j;->h:Ljava/lang/Object;

    iput v4, v0, LB2/j;->k:I

    iget-object p2, v2, LB2/c;->e:Ljava/lang/Object;

    check-cast p2, LB2/f;

    invoke-interface {p2, p1, v0}, LB2/f;->b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_6

    :goto_5
    return-object v1

    :pswitch_1
    instance-of v0, p2, LB2/b;

    if-eqz v0, :cond_9

    move-object v0, p2

    check-cast v0, LB2/b;

    iget v1, v0, LB2/b;->i:I

    const/high16 v2, -0x80000000

    and-int v3, v1, v2

    if-eqz v3, :cond_9

    sub-int/2addr v1, v2

    iput v1, v0, LB2/b;->i:I

    goto :goto_6

    :cond_9
    new-instance v0, LB2/b;

    invoke-direct {v0, p0, p2}, LB2/b;-><init>(LB2/c;Lg2/d;)V

    :goto_6
    iget-object p2, v0, LB2/b;->g:Ljava/lang/Object;

    sget-object v1, Lh2/a;->d:Lh2/a;

    iget v2, v0, LB2/b;->i:I

    sget-object v3, Lc2/m;->a:Lc2/m;

    const/4 v4, 0x1

    if-eqz v2, :cond_b

    if-ne v2, v4, :cond_a

    invoke-static {p2}, LZ0/d;->U(Ljava/lang/Object;)V

    goto :goto_7

    :cond_a
    new-instance p1, Ljava/lang/IllegalStateException;

    const-string p2, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {p1, p2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1

    :cond_b
    invoke-static {p2}, LZ0/d;->U(Ljava/lang/Object;)V

    iget-object p2, p0, LB2/c;->f:Ljava/lang/Object;

    check-cast p2, LB2/d;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p2, p0, LB2/c;->g:Ljava/lang/Object;

    check-cast p2, Lp2/o;

    iget-object v2, p2, Lp2/o;->d:Ljava/lang/Object;

    sget-object v5, LC2/c;->b:LD2/w;

    if-eq v2, v5, :cond_d

    sget-object v5, LB2/h;->e:LB2/h;

    invoke-virtual {v5, v2, p1}, LB2/h;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/Boolean;

    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v2

    if-nez v2, :cond_c

    goto :goto_8

    :cond_c
    :goto_7
    move-object v1, v3

    goto :goto_9

    :cond_d
    :goto_8
    iput-object p1, p2, Lp2/o;->d:Ljava/lang/Object;

    iput v4, v0, LB2/b;->i:I

    iget-object p2, p0, LB2/c;->e:Ljava/lang/Object;

    check-cast p2, LB2/f;

    invoke-interface {p2, p1, v0}, LB2/f;->b(Ljava/lang/Object;Lg2/d;)Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v1, :cond_c

    :goto_9
    return-object v1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
