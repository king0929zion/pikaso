.class public interface abstract LB2/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract o(LB2/f;Lg2/d;)Ljava/lang/Object;
.end method
