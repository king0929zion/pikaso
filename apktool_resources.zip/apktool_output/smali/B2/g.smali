.class public final LB2/g;
.super Li2/c;
.source "SourceFile"


# instance fields
.field public g:LB2/f;

.field public h:LA2/p;

.field public i:LA2/a;

.field public j:Z

.field public synthetic k:Ljava/lang/Object;

.field public l:I


# virtual methods
.method public final l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, LB2/g;->k:Ljava/lang/Object;

    iget p1, p0, LB2/g;->l:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LB2/g;->l:I

    const/4 p1, 0x0

    const/4 v0, 0x0

    invoke-static {p1, p1, v0, p0}, LB2/w;->c(LB2/f;LA2/n;ZLi2/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
