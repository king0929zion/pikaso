.class public abstract LD/k0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:LD/T;


# direct methods
.method public constructor <init>(Lo2/a;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LD/T;

    invoke-direct {v0, p1}, LD/T;-><init>(Lo2/a;)V

    iput-object v0, p0, LD/k0;->a:LD/T;

    return-void
.end method


# virtual methods
.method public abstract a(Ljava/lang/Object;)LD/l0;
.end method

.method public final b(LD/l0;LD/O0;)LD/O0;
    .locals 3

    instance-of v0, p2, LD/I;

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    iget-boolean v0, p1, LD/l0;->d:Z

    if-eqz v0, :cond_2

    move-object v1, p2

    check-cast v1, LD/I;

    iget-object p2, v1, LD/I;->a:LD/f0;

    invoke-virtual {p1}, LD/l0;->a()Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {p2, v0}, LD/f0;->setValue(Ljava/lang/Object;)V

    goto :goto_0

    :cond_0
    instance-of v0, p2, LD/N0;

    if-eqz v0, :cond_2

    iget-boolean v0, p1, LD/l0;->b:Z

    if-nez v0, :cond_1

    iget-object v0, p1, LD/l0;->e:Ljava/lang/Object;

    if-eqz v0, :cond_2

    :cond_1
    iget-boolean v0, p1, LD/l0;->d:Z

    if-nez v0, :cond_2

    invoke-virtual {p1}, LD/l0;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast p2, LD/N0;

    iget-object v2, p2, LD/N0;->a:Ljava/lang/Object;

    invoke-static {v0, v2}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_2

    move-object v1, p2

    :cond_2
    :goto_0
    if-nez v1, :cond_5

    iget-boolean p2, p1, LD/l0;->d:Z

    if-eqz p2, :cond_4

    new-instance p2, LD/I;

    iget-object v0, p1, LD/l0;->c:LD/H0;

    if-nez v0, :cond_3

    sget-object v0, LD/U;->i:LD/U;

    :cond_3
    sget v1, LD/b;->b:I

    new-instance v1, LD/f0;

    iget-object p1, p1, LD/l0;->e:Ljava/lang/Object;

    invoke-direct {v1, p1, v0}, LD/f0;-><init>(Ljava/lang/Object;LD/H0;)V

    invoke-direct {p2, v1}, LD/I;-><init>(LD/f0;)V

    :goto_1
    move-object v1, p2

    goto :goto_2

    :cond_4
    new-instance p2, LD/N0;

    invoke-virtual {p1}, LD/l0;->a()Ljava/lang/Object;

    move-result-object p1

    invoke-direct {p2, p1}, LD/N0;-><init>(Ljava/lang/Object;)V

    goto :goto_1

    :cond_5
    :goto_2
    return-object v1
.end method
