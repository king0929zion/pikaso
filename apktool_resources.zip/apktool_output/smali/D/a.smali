.class public final LD/a;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/a;


# static fields
.field public static final e:LD/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LD/a;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lp2/h;-><init>(I)V

    sput-object v0, LD/a;->e:LD/a;

    return-void
.end method


# virtual methods
.method public final c()Ljava/lang/Object;
    .locals 1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    if-eqz v0, :cond_0

    sget-object v0, LD/A;->d:LD/A;

    goto :goto_0

    :cond_0
    sget-object v0, LD/z0;->d:LD/z0;

    :goto_0
    return-object v0
.end method
