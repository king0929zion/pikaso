.class public final LD/u;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/e;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:LL/a;

.field public final synthetic g:I

.field public final synthetic h:Ljava/lang/Object;


# direct methods
.method public constructor <init>(LL/a;Ljava/lang/Object;I)V
    .locals 1

    const/4 v0, 0x2

    iput v0, p0, LD/u;->e:I

    .line 1
    iput-object p1, p0, LD/u;->f:LL/a;

    iput-object p2, p0, LD/u;->h:Ljava/lang/Object;

    iput p3, p0, LD/u;->g:I

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;LL/a;II)V
    .locals 0

    .line 2
    iput p4, p0, LD/u;->e:I

    iput-object p1, p0, LD/u;->h:Ljava/lang/Object;

    iput-object p2, p0, LD/u;->f:LL/a;

    iput p3, p0, LD/u;->g:I

    const/4 p1, 0x2

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    iget v0, p0, LD/u;->e:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    iget p2, p0, LD/u;->g:I

    or-int/lit8 p2, p2, 0x1

    invoke-static {p2}, LD/d;->J(I)I

    move-result p2

    iget-object v0, p0, LD/u;->h:Ljava/lang/Object;

    check-cast v0, Lo0/u;

    iget-object v1, p0, LD/u;->f:LL/a;

    invoke-static {v0, v1, p1, p2}, Lo0/S;->a(Lo0/u;LL/a;LD/n;I)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_0
    check-cast p1, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    iget p2, p0, LD/u;->g:I

    invoke-static {p2}, LD/d;->J(I)I

    move-result p2

    or-int/lit8 p2, p2, 0x1

    iget-object v0, p0, LD/u;->f:LL/a;

    iget-object v1, p0, LD/u;->h:Ljava/lang/Object;

    invoke-virtual {v0, v1, p1, p2}, LL/a;->b(Ljava/lang/Object;LD/n;I)Ljava/lang/Object;

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_1
    check-cast p1, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    iget p2, p0, LD/u;->g:I

    or-int/lit8 p2, p2, 0x1

    invoke-static {p2}, LD/d;->J(I)I

    move-result p2

    iget-object v0, p0, LD/u;->f:LL/a;

    iget-object v1, p0, LD/u;->h:Ljava/lang/Object;

    check-cast v1, LD/l0;

    invoke-static {v1, v0, p1, p2}, LD/d;->a(LD/l0;LL/a;LD/n;I)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_2
    check-cast p1, LD/n;

    check-cast p2, Ljava/lang/Number;

    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    iget-object p2, p0, LD/u;->h:Ljava/lang/Object;

    check-cast p2, [LD/l0;

    array-length v0, p2

    invoke-static {p2, v0}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object p2

    check-cast p2, [LD/l0;

    iget v0, p0, LD/u;->g:I

    or-int/lit8 v0, v0, 0x1

    invoke-static {v0}, LD/d;->J(I)I

    move-result v0

    iget-object v1, p0, LD/u;->f:LL/a;

    invoke-static {p2, v1, p1, v0}, LD/d;->b([LD/l0;LL/a;LD/n;I)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
