.class public final LD/f;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lo2/c;

.field public final b:Ly2/f;


# direct methods
.method public constructor <init>(Lo2/c;Ly2/f;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/f;->a:Lo2/c;

    iput-object p2, p0, LD/f;->b:Ly2/f;

    return-void
.end method
