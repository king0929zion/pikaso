.class public final LD/m0;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/c;


# instance fields
.field public final synthetic e:LD/n0;

.field public final synthetic f:I

.field public final synthetic g:Ln/w;


# direct methods
.method public constructor <init>(LD/n0;ILn/w;)V
    .locals 0

    iput-object p1, p0, LD/m0;->e:LD/n0;

    iput p2, p0, LD/m0;->f:I

    iput-object p3, p0, LD/m0;->g:Ln/w;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 18

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    check-cast v1, LD/p;

    iget-object v2, v0, LD/m0;->e:LD/n0;

    iget v3, v2, LD/n0;->e:I

    iget v4, v0, LD/m0;->f:I

    if-ne v3, v4, :cond_8

    iget-object v3, v2, LD/n0;->f:Ln/w;

    iget-object v5, v0, LD/m0;->g:Ln/w;

    invoke-static {v5, v3}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_8

    instance-of v3, v1, LD/t;

    if-eqz v3, :cond_8

    iget-object v3, v5, Ln/w;->a:[J

    array-length v6, v3

    add-int/lit8 v6, v6, -0x2

    if-ltz v6, :cond_8

    const/4 v8, 0x0

    :goto_0
    aget-wide v9, v3, v8

    not-long v11, v9

    const/4 v13, 0x7

    shl-long/2addr v11, v13

    and-long/2addr v11, v9

    const-wide v13, -0x7f7f7f7f7f7f7f80L    # -2.937446524422997E-306

    and-long/2addr v11, v13

    cmp-long v11, v11, v13

    if-eqz v11, :cond_7

    sub-int v11, v8, v6

    not-int v11, v11

    ushr-int/lit8 v11, v11, 0x1f

    const/16 v12, 0x8

    rsub-int/lit8 v11, v11, 0x8

    const/4 v13, 0x0

    :goto_1
    if-ge v13, v11, :cond_6

    const-wide/16 v14, 0xff

    and-long/2addr v14, v9

    const-wide/16 v16, 0x80

    cmp-long v14, v14, v16

    if-gez v14, :cond_5

    shl-int/lit8 v14, v8, 0x3

    add-int/2addr v14, v13

    iget-object v15, v5, Ln/w;->b:[Ljava/lang/Object;

    aget-object v15, v15, v14

    iget-object v7, v5, Ln/w;->c:[I

    aget v7, v7, v14

    if-eq v7, v4, :cond_0

    const/4 v7, 0x1

    goto :goto_2

    :cond_0
    const/4 v7, 0x0

    :goto_2
    if-eqz v7, :cond_2

    move-object v12, v1

    check-cast v12, LD/t;

    iget-object v0, v12, LD/t;->j:LA/t;

    invoke-virtual {v0, v15, v2}, LA/t;->D(Ljava/lang/Object;Ljava/lang/Object;)Z

    instance-of v0, v15, LD/D;

    if-eqz v0, :cond_2

    move-object v0, v15

    check-cast v0, LD/D;

    move-object/from16 v17, v1

    iget-object v1, v12, LD/t;->j:LA/t;

    iget-object v1, v1, LA/t;->e:Ljava/lang/Object;

    check-cast v1, Ln/y;

    invoke-virtual {v1, v0}, Ln/y;->b(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    iget-object v1, v12, LD/t;->m:LA/t;

    invoke-virtual {v1, v0}, LA/t;->F(Ljava/lang/Object;)V

    :cond_1
    iget-object v0, v2, LD/n0;->g:Ln/y;

    if-eqz v0, :cond_3

    invoke-virtual {v0, v15}, Ln/y;->g(Ljava/lang/Object;)V

    goto :goto_3

    :cond_2
    move-object/from16 v17, v1

    :cond_3
    :goto_3
    if-eqz v7, :cond_4

    invoke-virtual {v5, v14}, Ln/w;->e(I)V

    :cond_4
    const/16 v0, 0x8

    goto :goto_4

    :cond_5
    move-object/from16 v17, v1

    move v0, v12

    :goto_4
    shr-long/2addr v9, v0

    add-int/lit8 v13, v13, 0x1

    move v12, v0

    move-object/from16 v1, v17

    move-object/from16 v0, p0

    goto :goto_1

    :cond_6
    move-object/from16 v17, v1

    move v0, v12

    if-ne v11, v0, :cond_8

    goto :goto_5

    :cond_7
    move-object/from16 v17, v1

    :goto_5
    if-eq v8, v6, :cond_8

    add-int/lit8 v8, v8, 0x1

    move-object/from16 v0, p0

    move-object/from16 v1, v17

    goto/16 :goto_0

    :cond_8
    sget-object v0, Lc2/m;->a:Lc2/m;

    return-object v0
.end method
