.class public final LD/v;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final synthetic a:LD/v;

.field public static final b:LL/e;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    new-instance v0, LD/v;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD/v;->a:LD/v;

    sget-object v0, LL/e;->g:LL/e;

    sput-object v0, LD/v;->b:LL/e;

    return-void
.end method
