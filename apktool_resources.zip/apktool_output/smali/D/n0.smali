.class public final LD/n0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:I

.field public b:LD/t;

.field public c:LD/c;

.field public d:Lo2/e;

.field public e:I

.field public f:Ln/w;

.field public g:Ln/y;


# direct methods
.method public constructor <init>(LD/t;)V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/n0;->b:LD/t;

    return-void
.end method

.method public static a(LD/D;Ln/y;)Z
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.DerivedState<kotlin.Any?>"

    invoke-static {p0, v0}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p0}, LD/D;->h()LD/B;

    move-result-object v0

    iget-object v0, v0, LD/B;->f:Ljava/lang/Object;

    invoke-virtual {p1, p0}, Ln/y;->e(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    invoke-static {v0, p0}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result p0

    xor-int/lit8 p0, p0, 0x1

    return p0
.end method


# virtual methods
.method public final b()Z
    .locals 2

    iget-object v0, p0, LD/n0;->b:LD/t;

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    iget-object v0, p0, LD/n0;->c:LD/c;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, LD/c;->a()Z

    move-result v0

    goto :goto_0

    :cond_0
    move v0, v1

    :goto_0
    if-eqz v0, :cond_1

    const/4 v1, 0x1

    :cond_1
    return v1
.end method

.method public final c(Ljava/lang/Object;)I
    .locals 1

    iget-object v0, p0, LD/n0;->b:LD/t;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p0, p1}, LD/t;->m(LD/n0;Ljava/lang/Object;)I

    move-result p1

    if-nez p1, :cond_1

    :cond_0
    const/4 p1, 0x1

    :cond_1
    return p1
.end method

.method public final d()V
    .locals 2

    iget-object v0, p0, LD/n0;->b:LD/t;

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    iput-boolean v1, v0, LD/t;->r:Z

    :cond_0
    const/4 v0, 0x0

    iput-object v0, p0, LD/n0;->b:LD/t;

    iput-object v0, p0, LD/n0;->f:Ln/w;

    iput-object v0, p0, LD/n0;->g:Ln/y;

    return-void
.end method

.method public final e(Z)V
    .locals 0

    if-eqz p1, :cond_0

    iget p1, p0, LD/n0;->a:I

    or-int/lit8 p1, p1, 0x20

    iput p1, p0, LD/n0;->a:I

    goto :goto_0

    :cond_0
    iget p1, p0, LD/n0;->a:I

    and-int/lit8 p1, p1, -0x21

    iput p1, p0, LD/n0;->a:I

    :goto_0
    return-void
.end method
