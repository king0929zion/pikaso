.class public abstract LD/j;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LL/a;

.field public static final b:LL/a;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    sget-object v0, LD/i;->f:LD/i;

    new-instance v1, LL/a;

    const v2, 0x38ea4dba

    const/4 v3, 0x0

    invoke-direct {v1, v2, v3, v0}, LL/a;-><init>(IZLp2/h;)V

    sput-object v1, LD/j;->a:LL/a;

    sget-object v0, LD/i;->g:LD/i;

    new-instance v1, LL/a;

    const v2, 0x72535ae8

    invoke-direct {v1, v2, v3, v0}, LL/a;-><init>(IZLp2/h;)V

    sput-object v1, LD/j;->b:LL/a;

    return-void
.end method
