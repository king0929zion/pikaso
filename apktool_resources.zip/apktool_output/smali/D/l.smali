.class public final LD/l;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD/U;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    new-instance v0, LD/U;

    const/4 v1, 0x5

    invoke-direct {v0, v1}, LD/U;-><init>(I)V

    sput-object v0, LD/l;->a:LD/U;

    return-void
.end method
