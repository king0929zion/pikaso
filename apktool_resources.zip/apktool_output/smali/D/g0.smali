.class public final LD/g0;
.super Li2/c;
.source "SourceFile"


# instance fields
.field public g:LD/h0;

.field public h:Lo2/c;

.field public synthetic i:Ljava/lang/Object;

.field public final synthetic j:LD/h0;

.field public k:I


# direct methods
.method public constructor <init>(LD/h0;Li2/c;)V
    .locals 0

    iput-object p1, p0, LD/g0;->j:LD/h0;

    invoke-direct {p0, p2}, Li2/c;-><init>(Lg2/d;)V

    return-void
.end method


# virtual methods
.method public final l(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    iput-object p1, p0, LD/g0;->i:Ljava/lang/Object;

    iget p1, p0, LD/g0;->k:I

    const/high16 v0, -0x80000000

    or-int/2addr p1, v0

    iput p1, p0, LD/g0;->k:I

    iget-object p1, p0, LD/g0;->j:LD/h0;

    const/4 v0, 0x0

    invoke-virtual {p1, v0, p0}, LD/h0;->u(Lo2/c;Li2/c;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method
