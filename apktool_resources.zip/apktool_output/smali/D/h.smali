.class public final LD/h;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements LD/V;


# instance fields
.field public final d:LA0/c;

.field public final e:Ljava/lang/Object;

.field public f:Ljava/lang/Throwable;

.field public g:Ljava/util/ArrayList;

.field public h:Ljava/util/ArrayList;

.field public final i:LD/e;


# direct methods
.method public constructor <init>(LA0/c;)V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/h;->d:LA0/c;

    new-instance p1, Ljava/lang/Object;

    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/h;->e:Ljava/lang/Object;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LD/h;->g:Ljava/util/ArrayList;

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LD/h;->h:Ljava/util/ArrayList;

    new-instance p1, LD/e;

    const/4 v0, 0x0

    invoke-direct {p1, v0}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    iput-object p1, p0, LD/h;->i:LD/e;

    return-void
.end method


# virtual methods
.method public final c(J)V
    .locals 7

    iget-object v0, p0, LD/h;->e:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, LD/h;->g:Ljava/util/ArrayList;

    iget-object v2, p0, LD/h;->h:Ljava/util/ArrayList;

    iput-object v2, p0, LD/h;->g:Ljava/util/ArrayList;

    iput-object v1, p0, LD/h;->h:Ljava/util/ArrayList;

    iget-object v2, p0, LD/h;->i:LD/e;

    const/4 v3, 0x0

    invoke-virtual {v2, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    :goto_0
    if-ge v3, v2, :cond_0

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LD/f;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    iget-object v5, v4, LD/f;->a:Lo2/c;

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    invoke-interface {v5, v6}, Lo2/c;->i(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v5

    :try_start_2
    invoke-static {v5}, LZ0/d;->q(Ljava/lang/Throwable;)Lc2/i;

    move-result-object v5

    :goto_1
    iget-object v4, v4, LD/f;->b:Ly2/f;

    invoke-virtual {v4, v5}, Ly2/f;->t(Ljava/lang/Object;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    :catchall_1
    move-exception p1

    goto :goto_2

    :cond_0
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    monitor-exit v0

    return-void

    :goto_2
    monitor-exit v0

    throw p1
.end method

.method public final e(Lg2/h;)Lg2/i;
    .locals 0

    invoke-static {p0, p1}, LZ0/d;->H(Lg2/g;Lg2/h;)Lg2/i;

    move-result-object p1

    return-object p1
.end method

.method public final i(Lg2/i;)Lg2/i;
    .locals 0

    invoke-static {p0, p1}, LZ0/d;->K(Lg2/g;Lg2/i;)Lg2/i;

    move-result-object p1

    return-object p1
.end method

.method public final l(Ljava/lang/Object;Lo2/e;)Ljava/lang/Object;
    .locals 0

    invoke-interface {p2, p1, p0}, Lo2/e;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.method public final n(Lg2/h;)Lg2/g;
    .locals 0

    invoke-static {p0, p1}, LZ0/d;->w(Lg2/g;Lg2/h;)Lg2/g;

    move-result-object p1

    return-object p1
.end method

.method public final u(Lo2/c;Li2/c;)Ljava/lang/Object;
    .locals 7

    new-instance v0, Ly2/f;

    invoke-static {p2}, LZ/b;->z(Lg2/d;)Lg2/d;

    move-result-object p2

    const/4 v1, 0x1

    invoke-direct {v0, v1, p2}, Ly2/f;-><init>(ILg2/d;)V

    invoke-virtual {v0}, Ly2/f;->u()V

    new-instance p2, LD/f;

    invoke-direct {p2, p1, v0}, LD/f;-><init>(Lo2/c;Ly2/f;)V

    iget-object p1, p0, LD/h;->e:Ljava/lang/Object;

    monitor-enter p1

    :try_start_0
    iget-object v2, p0, LD/h;->f:Ljava/lang/Throwable;

    if-eqz v2, :cond_0

    invoke-static {v2}, LZ0/d;->q(Ljava/lang/Throwable;)Lc2/i;

    move-result-object p2

    invoke-virtual {v0, p2}, Ly2/f;->t(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit p1

    goto :goto_2

    :catchall_0
    move-exception p2

    goto :goto_3

    :cond_0
    :try_start_1
    iget-object v2, p0, LD/h;->g:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v2

    iget-object v3, p0, LD/h;->g:Ljava/util/ArrayList;

    invoke-virtual {v3, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    if-eqz v2, :cond_1

    iget-object v3, p0, LD/h;->i:LD/e;

    invoke-virtual {v3, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_1
    monitor-exit p1

    new-instance p1, LD/g;

    const/4 v1, 0x0

    invoke-direct {p1, p0, v1, p2}, LD/g;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-virtual {v0, p1}, Ly2/f;->x(Lo2/c;)V

    if-eqz v2, :cond_4

    iget-object p1, p0, LD/h;->d:LA0/c;

    :try_start_2
    invoke-virtual {p1}, LA0/c;->c()Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception p1

    iget-object p2, p0, LD/h;->e:Ljava/lang/Object;

    monitor-enter p2

    :try_start_3
    iget-object v1, p0, LD/h;->f:Ljava/lang/Throwable;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    if-eqz v1, :cond_2

    monitor-exit p2

    goto :goto_2

    :cond_2
    :try_start_4
    iput-object p1, p0, LD/h;->f:Ljava/lang/Throwable;

    iget-object v1, p0, LD/h;->g:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v3, 0x0

    move v4, v3

    :goto_0
    if-ge v4, v2, :cond_3

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LD/f;

    iget-object v5, v5, LD/f;->b:Ly2/f;

    invoke-static {p1}, LZ0/d;->q(Ljava/lang/Throwable;)Lc2/i;

    move-result-object v6

    invoke-virtual {v5, v6}, Ly2/f;->t(Ljava/lang/Object;)V

    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    :catchall_2
    move-exception p1

    goto :goto_1

    :cond_3
    iget-object p1, p0, LD/h;->g:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    iget-object p1, p0, LD/h;->i:LD/e;

    invoke-virtual {p1, v3}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    monitor-exit p2

    goto :goto_2

    :goto_1
    monitor-exit p2

    throw p1

    :cond_4
    :goto_2
    invoke-virtual {v0}, Ly2/f;->s()Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :goto_3
    monitor-exit p1

    throw p2
.end method
