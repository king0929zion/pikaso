.class public final LD/y;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/c;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .locals 0

    .line 1
    iput p1, p0, LD/y;->e:I

    iput-object p2, p0, LD/y;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method

.method public constructor <init>(LA/t;LS/d;Lp2/m;)V
    .locals 0

    const/4 p1, 0x7

    iput p1, p0, LD/y;->e:I

    .line 2
    iput-object p3, p0, LD/y;->f:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 8

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v4, p0, LD/y;->e:I

    packed-switch v4, :pswitch_data_0

    check-cast p1, Lz0/s;

    iget-object v2, p1, Lz0/s;->b:Lz0/l;

    new-instance v6, Lz0/s;

    iget v4, p1, Lz0/s;->d:I

    iget-object v5, p1, Lz0/s;->e:Ljava/lang/Object;

    const/4 v1, 0x0

    iget v3, p1, Lz0/s;->c:I

    move-object v0, v6

    invoke-direct/range {v0 .. v5}, Lz0/s;-><init>(Lz0/r;Lz0/l;IILjava/lang/Object;)V

    iget-object p1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast p1, Lz0/f;

    invoke-virtual {p1, v6}, Lz0/f;->a(Lz0/s;)Lz0/t;

    move-result-object p1

    iget-object p1, p1, Lz0/t;->d:Ljava/lang/Object;

    return-object p1

    :pswitch_0
    check-cast p1, Lt0/g;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Lt0/e;

    iget v0, v0, Lt0/e;->a:I

    invoke-static {p1, v0}, Lt0/p;->c(Lt0/g;I)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_1
    check-cast p1, LV/c;

    iget-wide v0, p1, LV/c;->a:J

    iget-object p1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast p1, Lq/l;

    iget-boolean v0, p1, Lq/l;->w:Z

    if-eqz v0, :cond_0

    iget-object p1, p1, Lq/l;->x:LA0/c;

    invoke-virtual {p1}, LA0/c;->c()Ljava/lang/Object;

    :cond_0
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_2
    check-cast p1, LW/o;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, LA/i;

    invoke-virtual {v0, p1, v2}, LA/i;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_3
    check-cast p1, LY/d;

    invoke-interface {p1}, LY/d;->H()LB0/a;

    move-result-object v0

    invoke-virtual {v0}, LB0/a;->j()LW/o;

    move-result-object v0

    iget-object v1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v1, Lo0/n0;

    iget-object v1, v1, Lo0/n0;->g:LA/i;

    if-eqz v1, :cond_1

    invoke-interface {p1}, LY/d;->H()LB0/a;

    move-result-object p1

    iget-object p1, p1, LB0/a;->c:Ljava/lang/Object;

    check-cast p1, LZ/d;

    invoke-virtual {v1, v0, p1}, LA/i;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_4
    sget-object p1, Lo0/m0;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    invoke-virtual {p1, v1, v3}, Ljava/util/concurrent/atomic/AtomicBoolean;->compareAndSet(ZZ)Z

    move-result p1

    sget-object v0, Lc2/m;->a:Lc2/m;

    if-eqz p1, :cond_2

    iget-object p1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast p1, LA2/b;

    invoke-interface {p1, v0}, LA2/q;->c(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    return-object v0

    :pswitch_5
    check-cast p1, LD/G;

    new-instance p1, Lo0/M;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Lo0/h0;

    invoke-direct {p1, v0}, Lo0/M;-><init>(Lo0/h0;)V

    return-object p1

    :pswitch_6
    check-cast p1, Landroid/content/res/Configuration;

    new-instance v0, Landroid/content/res/Configuration;

    invoke-direct {v0, p1}, Landroid/content/res/Configuration;-><init>(Landroid/content/res/Configuration;)V

    iget-object p1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast p1, LD/Z;

    invoke-interface {p1, v0}, LD/Z;->setValue(Ljava/lang/Object;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_7
    check-cast p1, LP/j;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, LF/d;

    invoke-virtual {v0, p1}, LF/d;->b(Ljava/lang/Object;)V

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    return-object p1

    :pswitch_8
    check-cast p1, Ln0/a;

    invoke-interface {p1}, Ln0/a;->g()Z

    move-result v0

    if-nez v0, :cond_3

    goto/16 :goto_3

    :cond_3
    invoke-interface {p1}, Ln0/a;->y()Ln0/A;

    move-result-object v0

    iget-boolean v0, v0, Ln0/A;->b:Z

    if-eqz v0, :cond_4

    invoke-interface {p1}, Ln0/a;->d()V

    :cond_4
    invoke-interface {p1}, Ln0/a;->y()Ln0/A;

    move-result-object v0

    iget-object v0, v0, Ln0/A;->g:Ljava/util/HashMap;

    invoke-virtual {v0}, Ljava/util/HashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    iget-object v2, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v2, Ln0/A;

    if-eqz v1, :cond_5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map$Entry;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ll0/f;

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    invoke-interface {p1}, Ln0/a;->A()Ln0/p;

    move-result-object v4

    invoke-static {v2, v3, v1, v4}, Ln0/A;->a(Ln0/A;Ll0/f;ILn0/Y;)V

    goto :goto_0

    :cond_5
    invoke-interface {p1}, Ln0/a;->A()Ln0/p;

    move-result-object p1

    iget-object p1, p1, Ln0/Y;->p:Ln0/Y;

    invoke-static {p1}, Lp2/g;->b(Ljava/lang/Object;)V

    :goto_1
    iget-object v0, v2, Ln0/A;->a:Ll0/o;

    invoke-interface {v0}, Ln0/a;->A()Ln0/p;

    move-result-object v0

    invoke-virtual {p1, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    invoke-virtual {v2, p1}, Ln0/A;->b(Ln0/Y;)Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_2
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ll0/f;

    invoke-virtual {v2, p1, v1}, Ln0/A;->c(Ln0/Y;Ll0/f;)I

    move-result v3

    invoke-static {v2, v1, v3, p1}, Ln0/A;->a(Ln0/A;Ll0/f;ILn0/Y;)V

    goto :goto_2

    :cond_6
    iget-object p1, p1, Ln0/Y;->p:Ln0/Y;

    invoke-static {p1}, Lp2/g;->b(Ljava/lang/Object;)V

    goto :goto_1

    :cond_7
    :goto_3
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_9
    check-cast p1, Ll0/n;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    :goto_4
    if-ge v1, v2, :cond_8

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ll0/o;

    invoke-static {p1, v4}, Ll0/n;->g(Ll0/n;Ll0/o;)V

    add-int/2addr v1, v3

    goto :goto_4

    :cond_8
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_a
    check-cast p1, Ljava/lang/Throwable;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Lh0/p;

    iget-object v1, v0, Lh0/p;->f:Ly2/f;

    if-eqz v1, :cond_9

    invoke-virtual {v1, p1}, Ly2/f;->n(Ljava/lang/Throwable;)Z

    :cond_9
    iput-object v2, v0, Lh0/p;->f:Ly2/f;

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_b
    check-cast p1, Ljava/util/Map$Entry;

    const-string v0, "it"

    invoke-static {p1, v0}, Lp2/g;->e(Ljava/lang/Object;Ljava/lang/String;)V

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Ld2/e;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-interface {p1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const-string v3, "(this Map)"

    if-ne v2, v0, :cond_a

    move-object v2, v3

    goto :goto_5

    :cond_a
    invoke-static {v2}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    :goto_5
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/16 v2, 0x3d

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    invoke-interface {p1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p1

    if-ne p1, v0, :cond_b

    goto :goto_6

    :cond_b
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v3

    :goto_6
    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    return-object p1

    :pswitch_c
    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Ld2/a;

    if-ne p1, v0, :cond_c

    const-string p1, "(this Collection)"

    goto :goto_7

    :cond_c
    invoke-static {p1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    :goto_7
    return-object p1

    :pswitch_d
    check-cast p1, Lc0/B;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Lc0/c;

    invoke-virtual {v0, p1}, Lc0/c;->g(Lc0/B;)V

    iget-object v0, v0, Lc0/c;->i:Lp2/h;

    if-eqz v0, :cond_d

    invoke-interface {v0, p1}, Lo2/c;->i(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_d
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_e
    check-cast p1, LW/F;

    iget-object v1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v1, LW/I;

    iget v4, v1, LW/I;->q:F

    iget v5, p1, LW/F;->e:F

    cmpg-float v5, v5, v4

    if-nez v5, :cond_e

    goto :goto_8

    :cond_e
    iget v5, p1, LW/F;->d:I

    or-int/2addr v3, v5

    iput v3, p1, LW/F;->d:I

    iput v4, p1, LW/F;->e:F

    :goto_8
    iget v3, v1, LW/I;->r:F

    iget v4, p1, LW/F;->f:F

    cmpg-float v4, v4, v3

    if-nez v4, :cond_f

    goto :goto_9

    :cond_f
    iget v4, p1, LW/F;->d:I

    or-int/2addr v0, v4

    iput v0, p1, LW/F;->d:I

    iput v3, p1, LW/F;->f:F

    :goto_9
    iget v0, v1, LW/I;->s:F

    iget v3, p1, LW/F;->g:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_10

    goto :goto_a

    :cond_10
    iget v3, p1, LW/F;->d:I

    or-int/lit8 v3, v3, 0x4

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->g:F

    :goto_a
    iget v0, v1, LW/I;->t:F

    iget v3, p1, LW/F;->h:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_11

    goto :goto_b

    :cond_11
    iget v3, p1, LW/F;->d:I

    or-int/lit8 v3, v3, 0x8

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->h:F

    :goto_b
    iget v0, v1, LW/I;->u:F

    iget v3, p1, LW/F;->i:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_12

    goto :goto_c

    :cond_12
    iget v3, p1, LW/F;->d:I

    or-int/lit8 v3, v3, 0x10

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->i:F

    :goto_c
    iget v0, v1, LW/I;->v:F

    iget v3, p1, LW/F;->j:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_13

    goto :goto_d

    :cond_13
    iget v3, p1, LW/F;->d:I

    or-int/lit8 v3, v3, 0x20

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->j:F

    :goto_d
    iget v0, v1, LW/I;->w:F

    iget v3, p1, LW/F;->m:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_14

    goto :goto_e

    :cond_14
    iget v3, p1, LW/F;->d:I

    or-int/lit16 v3, v3, 0x100

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->m:F

    :goto_e
    iget v0, v1, LW/I;->x:F

    iget v3, p1, LW/F;->n:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_15

    goto :goto_f

    :cond_15
    iget v3, p1, LW/F;->d:I

    or-int/lit16 v3, v3, 0x200

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->n:F

    :goto_f
    iget v0, v1, LW/I;->y:F

    iget v3, p1, LW/F;->o:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_16

    goto :goto_10

    :cond_16
    iget v3, p1, LW/F;->d:I

    or-int/lit16 v3, v3, 0x400

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->o:F

    :goto_10
    iget v0, v1, LW/I;->z:F

    iget v3, p1, LW/F;->p:F

    cmpg-float v3, v3, v0

    if-nez v3, :cond_17

    goto :goto_11

    :cond_17
    iget v3, p1, LW/F;->d:I

    or-int/lit16 v3, v3, 0x800

    iput v3, p1, LW/F;->d:I

    iput v0, p1, LW/F;->p:F

    :goto_11
    iget-wide v3, v1, LW/I;->A:J

    iget-wide v5, p1, LW/F;->q:J

    sget v0, LW/K;->b:I

    cmp-long v0, v5, v3

    if-nez v0, :cond_18

    goto :goto_12

    :cond_18
    iget v0, p1, LW/F;->d:I

    or-int/lit16 v0, v0, 0x1000

    iput v0, p1, LW/F;->d:I

    iput-wide v3, p1, LW/F;->q:J

    :goto_12
    iget-object v0, v1, LW/I;->B:LW/H;

    iget-object v3, p1, LW/F;->r:LW/H;

    invoke-static {v3, v0}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_19

    iget v3, p1, LW/F;->d:I

    or-int/lit16 v3, v3, 0x2000

    iput v3, p1, LW/F;->d:I

    iput-object v0, p1, LW/F;->r:LW/H;

    :cond_19
    iget-boolean v0, v1, LW/I;->C:Z

    iget-boolean v3, p1, LW/F;->s:Z

    if-eq v3, v0, :cond_1a

    iget v3, p1, LW/F;->d:I

    or-int/lit16 v3, v3, 0x4000

    iput v3, p1, LW/F;->d:I

    iput-boolean v0, p1, LW/F;->s:Z

    :cond_1a
    invoke-static {v2, v2}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1b

    iget v0, p1, LW/F;->d:I

    const/high16 v2, 0x20000

    or-int/2addr v0, v2

    iput v0, p1, LW/F;->d:I

    :cond_1b
    iget-wide v2, v1, LW/I;->D:J

    iget-wide v4, p1, LW/F;->k:J

    invoke-static {v4, v5, v2, v3}, LW/r;->c(JJ)Z

    move-result v0

    if-nez v0, :cond_1c

    iget v0, p1, LW/F;->d:I

    or-int/lit8 v0, v0, 0x40

    iput v0, p1, LW/F;->d:I

    iput-wide v2, p1, LW/F;->k:J

    :cond_1c
    iget-wide v2, v1, LW/I;->E:J

    iget-wide v4, p1, LW/F;->l:J

    invoke-static {v4, v5, v2, v3}, LW/r;->c(JJ)Z

    move-result v0

    if-nez v0, :cond_1d

    iget v0, p1, LW/F;->d:I

    or-int/lit16 v0, v0, 0x80

    iput v0, p1, LW/F;->d:I

    iput-wide v2, p1, LW/F;->l:J

    :cond_1d
    iget v0, v1, LW/I;->F:I

    iget v1, p1, LW/F;->t:I

    invoke-static {v1, v0}, LW/D;->m(II)Z

    move-result v1

    if-nez v1, :cond_1e

    iget v1, p1, LW/F;->d:I

    const v2, 0x8000

    or-int/2addr v1, v2

    iput v1, p1, LW/F;->d:I

    iput v0, p1, LW/F;->t:I

    :cond_1e
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_f
    check-cast p1, LS/d;

    iget-boolean p1, p1, LP/k;->p:Z

    if-nez p1, :cond_1f

    sget-object p1, Ln0/n0;->e:Ln0/n0;

    goto :goto_13

    :cond_1f
    iget-object p1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast p1, Lp2/m;

    iget-boolean v0, p1, Lp2/m;->d:Z

    iput-boolean v0, p1, Lp2/m;->d:Z

    sget-object p1, Ln0/n0;->d:Ln0/n0;

    :goto_13
    return-object p1

    :pswitch_10
    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, LN/v;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object v1, v0, LN/v;->f:LF/d;

    monitor-enter v1

    :try_start_0
    iget-object v0, v0, LN/v;->h:LN/u;

    invoke-static {v0}, Lp2/g;->b(Ljava/lang/Object;)V

    iget-object v2, v0, LN/u;->b:Ln0/f0;

    invoke-static {v2}, Lp2/g;->b(Ljava/lang/Object;)V

    iget v3, v0, LN/u;->d:I

    iget-object v4, v0, LN/u;->c:Ln/w;

    if-nez v4, :cond_20

    new-instance v4, Ln/w;

    invoke-direct {v4}, Ln/w;-><init>()V

    iput-object v4, v0, LN/u;->c:Ln/w;

    iget-object v5, v0, LN/u;->f:Ln/y;

    invoke-virtual {v5, v2, v4}, Ln/y;->j(Ljava/lang/Object;Ljava/lang/Object;)V

    :cond_20
    invoke-virtual {v0, p1, v3, v2, v4}, LN/u;->c(Ljava/lang/Object;ILjava/lang/Object;Ln/w;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1

    throw p1

    :pswitch_11
    check-cast p1, LN/l;

    sget-object v0, LN/o;->b:Ljava/lang/Object;

    monitor-enter v0

    :try_start_1
    sget v1, LN/o;->d:I

    add-int/2addr v3, v1

    sput v3, LN/o;->d:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit v0

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, Lo2/c;

    new-instance v2, LN/f;

    invoke-direct {v2, v1, p1, v0}, LN/f;-><init>(ILN/l;Lo2/c;)V

    return-object v2

    :catchall_1
    move-exception p1

    monitor-exit v0

    throw p1

    :pswitch_12
    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    :goto_14
    if-ge v1, v2, :cond_21

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lo2/c;

    invoke-interface {v4, p1}, Lo2/c;->i(Ljava/lang/Object;)Ljava/lang/Object;

    add-int/2addr v1, v3

    goto :goto_14

    :cond_21
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_13
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast p1, LG2/h;

    invoke-virtual {p1}, LG2/h;->b()V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_14
    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, LD/t;

    invoke-virtual {v0, p1}, LD/t;->t(Ljava/lang/Object;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_15
    check-cast p1, Ljava/lang/Throwable;

    const-string v1, "Recomposer effect job completed"

    new-instance v3, Ljava/util/concurrent/CancellationException;

    invoke-direct {v3, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, p1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    iget-object v1, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v1, LD/v0;

    iget-object v4, v1, LD/v0;->b:Ljava/lang/Object;

    monitor-enter v4

    :try_start_2
    iget-object v5, v1, LD/v0;->c:Ly2/S;

    if-eqz v5, :cond_22

    iget-object v6, v1, LD/v0;->r:LB2/G;

    sget-object v7, LD/o0;->e:LD/o0;

    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v6, v2, v7}, LB2/G;->g(Ljava/lang/Object;Ljava/lang/Object;)Z

    sget-object v6, LD/v0;->v:LB2/G;

    invoke-interface {v5, v3}, Ly2/S;->a(Ljava/util/concurrent/CancellationException;)V

    iput-object v2, v1, LD/v0;->o:Ly2/f;

    new-instance v2, LD/g;

    invoke-direct {v2, v1, v0, p1}, LD/g;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-interface {v5, v2}, Ly2/S;->q(Lo2/c;)Ly2/C;

    goto :goto_15

    :catchall_2
    move-exception p1

    goto :goto_16

    :cond_22
    iput-object v3, v1, LD/v0;->d:Ljava/lang/Throwable;

    iget-object p1, v1, LD/v0;->r:LB2/G;

    sget-object v0, LD/o0;->d:LD/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v2, v0}, LB2/G;->g(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :goto_15
    monitor-exit v4

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :goto_16
    monitor-exit v4

    throw p1

    :pswitch_16
    check-cast p1, Ljava/lang/Throwable;

    sget-object p1, LD/A;->e:Landroid/view/Choreographer;

    iget-object v0, p0, LD/y;->f:Ljava/lang/Object;

    check-cast v0, LD/z;

    invoke-virtual {p1, v0}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_16
        :pswitch_15
        :pswitch_14
        :pswitch_13
        :pswitch_12
        :pswitch_11
        :pswitch_10
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
