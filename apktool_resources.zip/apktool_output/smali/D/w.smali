.class public interface abstract LD/w;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final b:LD/v;


# direct methods
.method static constructor <clinit>()V
    .locals 1

    sget-object v0, LD/v;->a:LD/v;

    sput-object v0, LD/w;->b:LD/v;

    return-void
.end method
