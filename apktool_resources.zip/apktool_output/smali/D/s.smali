.class public final LD/s;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final synthetic a:I

.field public final b:Ljava/lang/Object;

.field public final c:Ljava/lang/Object;

.field public d:Ljava/lang/Object;

.field public final e:Ljava/lang/Object;

.field public f:Ljava/lang/Object;

.field public g:Ljava/lang/Object;

.field public h:Ljava/lang/Object;

.field public i:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ln/A;)V
    .locals 1

    const/4 v0, 0x0

    iput v0, p0, LD/s;->a:I

    .line 6
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, LD/s;->b:Ljava/lang/Object;

    .line 8
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LD/s;->c:Ljava/lang/Object;

    .line 9
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LD/s;->d:Ljava/lang/Object;

    .line 10
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LD/s;->e:Ljava/lang/Object;

    .line 11
    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, LD/s;->f:Ljava/lang/Object;

    .line 12
    new-instance p1, Ln/q;

    invoke-direct {p1}, Ln/q;-><init>()V

    iput-object p1, p0, LD/s;->h:Ljava/lang/Object;

    .line 13
    new-instance p1, Ln/q;

    invoke-direct {p1}, Ln/q;-><init>()V

    iput-object p1, p0, LD/s;->i:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Ln0/z;)V
    .locals 1

    const/4 v0, 0x1

    iput v0, p0, LD/s;->a:I

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, LD/s;->b:Ljava/lang/Object;

    .line 2
    new-instance v0, Ln0/p;

    invoke-direct {v0, p1}, Ln0/p;-><init>(Ln0/z;)V

    iput-object v0, p0, LD/s;->c:Ljava/lang/Object;

    .line 3
    iput-object v0, p0, LD/s;->d:Ljava/lang/Object;

    .line 4
    iget-object p1, v0, Ln0/p;->K:Ln0/m0;

    iput-object p1, p0, LD/s;->e:Ljava/lang/Object;

    .line 5
    iput-object p1, p0, LD/s;->f:Ljava/lang/Object;

    return-void
.end method

.method public static final a(LD/s;LP/k;Ln0/Y;)V
    .locals 1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget-object p1, p1, LP/k;->h:LP/k;

    :goto_0
    if-eqz p1, :cond_3

    sget-object v0, Ln0/U;->a:Ln0/T;

    if-ne p1, v0, :cond_1

    iget-object p1, p0, LD/s;->b:Ljava/lang/Object;

    check-cast p1, Ln0/z;

    invoke-virtual {p1}, Ln0/z;->k()Ln0/z;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p1, Ln0/z;->x:LD/s;

    iget-object p1, p1, LD/s;->c:Ljava/lang/Object;

    check-cast p1, Ln0/p;

    goto :goto_1

    :cond_0
    const/4 p1, 0x0

    :goto_1
    iput-object p1, p2, Ln0/Y;->p:Ln0/Y;

    iput-object p2, p0, LD/s;->d:Ljava/lang/Object;

    goto :goto_2

    :cond_1
    iget v0, p1, LP/k;->f:I

    and-int/lit8 v0, v0, 0x2

    if-eqz v0, :cond_2

    goto :goto_2

    :cond_2
    invoke-virtual {p1, p2}, LP/k;->e0(Ln0/Y;)V

    iget-object p1, p1, LP/k;->h:LP/k;

    goto :goto_0

    :cond_3
    :goto_2
    return-void
.end method

.method public static b(LP/j;LP/k;)LP/k;
    .locals 4

    instance-of v0, p0, Ln0/P;

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    check-cast p0, Ln0/P;

    invoke-virtual {p0}, Ln0/P;->d()LP/k;

    move-result-object p0

    invoke-static {p0}, Ln0/Z;->f(LP/k;)I

    move-result v0

    iput v0, p0, LP/k;->f:I

    goto :goto_1

    :cond_0
    new-instance v0, Ln0/b;

    invoke-direct {v0}, LP/k;-><init>()V

    sget-object v2, Ln0/Z;->a:Ln/w;

    instance-of v2, p0, Lq/F;

    if-eqz v2, :cond_1

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    move v2, v1

    :goto_0
    instance-of v3, p0, Landroidx/compose/ui/semantics/AppendedSemanticsElement;

    if-eqz v3, :cond_2

    or-int/lit8 v2, v2, 0x8

    :cond_2
    iput v2, v0, LP/k;->f:I

    iput-object p0, v0, Ln0/b;->q:LP/j;

    new-instance p0, Ljava/util/HashSet;

    invoke-direct {p0}, Ljava/util/HashSet;-><init>()V

    move-object p0, v0

    :goto_1
    iget-boolean v0, p0, LP/k;->p:Z

    if-nez v0, :cond_4

    iput-boolean v1, p0, LP/k;->l:Z

    iget-object v0, p1, LP/k;->i:LP/k;

    if-eqz v0, :cond_3

    iput-object p0, v0, LP/k;->h:LP/k;

    iput-object v0, p0, LP/k;->i:LP/k;

    :cond_3
    iput-object p0, p1, LP/k;->i:LP/k;

    iput-object p1, p0, LP/k;->h:LP/k;

    return-object p0

    :cond_4
    const-string p0, "A ModifierNodeElement cannot return an already attached node from create() "

    invoke-static {p0}, LZ0/d;->S(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static c(LP/k;)LP/k;
    .locals 3

    iget-boolean v0, p0, LP/k;->p:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_1

    sget-object v2, Ln0/Z;->a:Ln/w;

    if-eqz v0, :cond_0

    const/4 v0, -0x1

    const/4 v2, 0x2

    invoke-static {p0, v0, v2}, Ln0/Z;->b(LP/k;II)V

    invoke-virtual {p0}, LP/k;->c0()V

    invoke-virtual {p0}, LP/k;->X()V

    goto :goto_0

    :cond_0
    const-string p0, "autoInvalidateRemovedNode called on unattached node"

    invoke-static {p0}, LZ0/d;->S(Ljava/lang/String;)V

    throw v1

    :cond_1
    :goto_0
    iget-object v0, p0, LP/k;->i:LP/k;

    iget-object v2, p0, LP/k;->h:LP/k;

    if-eqz v0, :cond_2

    iput-object v2, v0, LP/k;->h:LP/k;

    iput-object v1, p0, LP/k;->i:LP/k;

    :cond_2
    if-eqz v2, :cond_3

    iput-object v0, v2, LP/k;->i:LP/k;

    iput-object v1, p0, LP/k;->h:LP/k;

    :cond_3
    invoke-static {v2}, Lp2/g;->b(Ljava/lang/Object;)V

    return-object v2
.end method

.method public static k(LP/j;LP/j;LP/k;)V
    .locals 2

    instance-of p0, p0, Ln0/P;

    const/4 v0, 0x1

    if-eqz p0, :cond_1

    instance-of p0, p1, Ln0/P;

    if-eqz p0, :cond_1

    check-cast p1, Ln0/P;

    sget-object p0, Ln0/U;->a:Ln0/T;

    const-string p0, "null cannot be cast to non-null type T of androidx.compose.ui.node.NodeChainKt.updateUnsafe"

    invoke-static {p2, p0}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-virtual {p1, p2}, Ln0/P;->e(LP/k;)V

    iget-boolean p0, p2, LP/k;->p:Z

    if-eqz p0, :cond_0

    invoke-static {p2}, Ln0/Z;->d(LP/k;)V

    goto :goto_1

    :cond_0
    iput-boolean v0, p2, LP/k;->m:Z

    goto :goto_1

    :cond_1
    instance-of p0, p2, Ln0/b;

    if-eqz p0, :cond_7

    move-object p0, p2

    check-cast p0, Ln0/b;

    iget-boolean v1, p0, LP/k;->p:Z

    if-eqz v1, :cond_2

    invoke-virtual {p0}, Ln0/b;->g0()V

    :cond_2
    iput-object p1, p0, Ln0/b;->q:LP/j;

    sget-object v1, Ln0/Z;->a:Ln/w;

    instance-of v1, p1, Lq/F;

    if-eqz v1, :cond_3

    const/4 v1, 0x5

    goto :goto_0

    :cond_3
    move v1, v0

    :goto_0
    instance-of p1, p1, Landroidx/compose/ui/semantics/AppendedSemanticsElement;

    if-eqz p1, :cond_4

    or-int/lit8 v1, v1, 0x8

    :cond_4
    iput v1, p0, LP/k;->f:I

    iget-boolean p1, p0, LP/k;->p:Z

    if-eqz p1, :cond_5

    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Ln0/b;->f0(Z)V

    :cond_5
    iget-boolean p0, p2, LP/k;->p:Z

    if-eqz p0, :cond_6

    invoke-static {p2}, Ln0/Z;->d(LP/k;)V

    goto :goto_1

    :cond_6
    iput-boolean v0, p2, LP/k;->m:Z

    :goto_1
    return-void

    :cond_7
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string p1, "Unknown Modifier.Node type"

    invoke-direct {p0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method


# virtual methods
.method public d()V
    .locals 3

    iget-object v0, p0, LD/s;->b:Ljava/lang/Object;

    check-cast v0, Ln/A;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_1

    const-string v1, "Compose:abandons"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_0
    invoke-virtual {v0}, Ln/A;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    move-object v1, v0

    check-cast v1, LJ/c;

    iget-object v1, v1, LJ/c;->f:Ljava/lang/Object;

    check-cast v1, Lw2/g;

    invoke-virtual {v1}, Lw2/g;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_0

    move-object v1, v0

    check-cast v1, LJ/c;

    iget-object v1, v1, LJ/c;->f:Ljava/lang/Object;

    check-cast v1, Lw2/g;

    invoke-virtual {v1}, Lw2/g;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LD/w0;

    move-object v2, v0

    check-cast v2, LJ/c;

    invoke-virtual {v2}, LJ/c;->remove()V

    invoke-interface {v1}, LD/w0;->c()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    goto :goto_1

    :cond_0
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_2

    :goto_1
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :cond_1
    :goto_2
    return-void
.end method

.method public e()V
    .locals 9

    const/high16 v0, -0x80000000

    invoke-virtual {p0, v0}, LD/s;->g(I)V

    iget-object v0, p0, LD/s;->d:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    const/4 v2, 0x0

    iget-object v3, p0, LD/s;->b:Ljava/lang/Object;

    check-cast v3, Ln/A;

    if-nez v1, :cond_5

    const-string v1, "Compose:onForgotten"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_0
    iget-object v1, p0, LD/s;->g:Ljava/lang/Object;

    check-cast v1, Ln/B;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v5, 0x1

    sub-int/2addr v4, v5

    :goto_0
    const/4 v6, -0x1

    if-ge v6, v4, :cond_4

    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v6

    instance-of v7, v6, LD/w0;

    if-eqz v7, :cond_0

    invoke-virtual {v3, v6}, Ln/A;->remove(Ljava/lang/Object;)Z

    move-object v7, v6

    check-cast v7, LD/w0;

    invoke-interface {v7}, LD/w0;->a()V

    goto :goto_1

    :catchall_0
    move-exception v0

    goto :goto_3

    :cond_0
    :goto_1
    instance-of v7, v6, Ln0/z;

    if-eqz v7, :cond_3

    if-eqz v1, :cond_2

    invoke-virtual {v1, v6}, Ln/B;->c(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_2

    check-cast v6, Ln0/z;

    iget-object v6, v6, Ln0/z;->x:LD/s;

    iget-object v7, v6, LD/s;->d:Ljava/lang/Object;

    check-cast v7, Ln0/Y;

    iget-object v6, v6, LD/s;->c:Ljava/lang/Object;

    check-cast v6, Ln0/p;

    iget-object v6, v6, Ln0/Y;->o:Ln0/Y;

    :goto_2
    invoke-static {v7, v6}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v8

    if-nez v8, :cond_3

    if-eqz v7, :cond_3

    iput-boolean v5, v7, Ln0/Y;->q:Z

    iget-object v8, v7, Ln0/Y;->D:LA0/c;

    invoke-virtual {v8}, LA0/c;->c()Ljava/lang/Object;

    iget-object v8, v7, Ln0/Y;->F:Ln0/d0;

    if-eqz v8, :cond_1

    const/4 v8, 0x0

    invoke-virtual {v7, v8, v2}, Ln0/Y;->J0(Lo2/c;Z)V

    iget-object v8, v7, Ln0/Y;->n:Ln0/z;

    invoke-virtual {v8, v2}, Ln0/z;->E(Z)V

    :cond_1
    iget-object v7, v7, Ln0/Y;->o:Ln0/Y;

    goto :goto_2

    :cond_2
    check-cast v6, Ln0/z;

    invoke-virtual {v6}, Ln0/z;->z()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_3
    add-int/lit8 v4, v4, -0x1

    goto :goto_0

    :cond_4
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_4

    :goto_3
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :cond_5
    :goto_4
    iget-object v0, p0, LD/s;->c:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    const-string v1, "Compose:onRemembered"

    invoke-static {v1}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    :try_start_1
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    :goto_5
    if-ge v2, v1, :cond_6

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, LD/w0;

    invoke-virtual {v3, v4}, Ln/A;->remove(Ljava/lang/Object;)Z

    invoke-interface {v4}, LD/w0;->b()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    add-int/lit8 v2, v2, 0x1

    goto :goto_5

    :catchall_1
    move-exception v0

    goto :goto_6

    :cond_6
    invoke-static {}, Landroid/os/Trace;->endSection()V

    goto :goto_7

    :goto_6
    invoke-static {}, Landroid/os/Trace;->endSection()V

    throw v0

    :cond_7
    :goto_7
    return-void
.end method

.method public f(I)Z
    .locals 1

    iget-object v0, p0, LD/s;->f:Ljava/lang/Object;

    check-cast v0, LP/k;

    iget v0, v0, LP/k;->g:I

    and-int/2addr p1, v0

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public g(I)V
    .locals 10

    iget-object v0, p0, LD/s;->f:Ljava/lang/Object;

    check-cast v0, Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-nez v1, :cond_7

    const/4 v1, 0x0

    const/4 v2, 0x0

    move v5, v1

    move-object v3, v2

    move-object v4, v3

    :goto_0
    iget-object v6, p0, LD/s;->i:Ljava/lang/Object;

    check-cast v6, Ln/q;

    iget v7, v6, Ln/q;->b:I

    const-string v8, "null cannot be cast to non-null type androidx.collection.MutableIntList"

    if-ge v5, v7, :cond_2

    invoke-virtual {v6, v5}, Ln/q;->b(I)I

    move-result v7

    if-gt p1, v7, :cond_1

    invoke-virtual {v0, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    move-result-object v7

    invoke-virtual {v6, v5}, Ln/q;->c(I)I

    move-result v6

    iget-object v9, p0, LD/s;->h:Ljava/lang/Object;

    check-cast v9, Ln/q;

    invoke-virtual {v9, v5}, Ln/q;->c(I)I

    move-result v9

    if-nez v2, :cond_0

    filled-new-array {v7}, [Ljava/lang/Object;

    move-result-object v2

    invoke-static {v2}, Ld2/l;->V([Ljava/lang/Object;)Ljava/util/ArrayList;

    move-result-object v2

    new-instance v4, Ln/q;

    invoke-direct {v4}, Ln/q;-><init>()V

    invoke-virtual {v4, v6}, Ln/q;->a(I)V

    new-instance v3, Ln/q;

    invoke-direct {v3}, Ln/q;-><init>()V

    invoke-virtual {v3, v9}, Ln/q;->a(I)V

    goto :goto_0

    :cond_0
    invoke-static {v3, v8}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4, v8}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v2, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    invoke-virtual {v4, v6}, Ln/q;->a(I)V

    invoke-virtual {v3, v9}, Ln/q;->a(I)V

    goto :goto_0

    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_2
    if-eqz v2, :cond_7

    invoke-static {v3, v8}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-static {v4, v8}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result p1

    add-int/lit8 p1, p1, -0x1

    :goto_1
    if-ge v1, p1, :cond_6

    add-int/lit8 v0, v1, 0x1

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v5

    move v6, v0

    :goto_2
    if-ge v6, v5, :cond_5

    invoke-virtual {v4, v1}, Ln/q;->b(I)I

    move-result v7

    invoke-virtual {v4, v6}, Ln/q;->b(I)I

    move-result v8

    if-lt v7, v8, :cond_3

    if-ne v8, v7, :cond_4

    invoke-virtual {v3, v1}, Ln/q;->b(I)I

    move-result v7

    invoke-virtual {v3, v6}, Ln/q;->b(I)I

    move-result v8

    if-ge v7, v8, :cond_4

    :cond_3
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v7

    invoke-interface {v2, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    invoke-interface {v2, v1, v8}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    invoke-interface {v2, v6, v7}, Ljava/util/List;->set(ILjava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v3, v1}, Ln/q;->b(I)I

    move-result v7

    invoke-virtual {v3, v6}, Ln/q;->b(I)I

    move-result v8

    invoke-virtual {v3, v1, v8}, Ln/q;->d(II)V

    invoke-virtual {v3, v6, v7}, Ln/q;->d(II)V

    invoke-virtual {v4, v1}, Ln/q;->b(I)I

    move-result v7

    invoke-virtual {v4, v6}, Ln/q;->b(I)I

    move-result v8

    invoke-virtual {v4, v1, v8}, Ln/q;->d(II)V

    invoke-virtual {v4, v6, v7}, Ln/q;->d(II)V

    :cond_4
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    :cond_5
    move v1, v0

    goto :goto_1

    :cond_6
    iget-object p1, p0, LD/s;->d:Ljava/lang/Object;

    check-cast p1, Ljava/util/ArrayList;

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->addAll(Ljava/util/Collection;)Z

    :cond_7
    return-void
.end method

.method public h(Ljava/lang/Object;III)V
    .locals 0

    invoke-virtual {p0, p2}, LD/s;->g(I)V

    if-ltz p4, :cond_0

    if-ge p4, p2, :cond_0

    iget-object p2, p0, LD/s;->f:Ljava/lang/Object;

    check-cast p2, Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iget-object p1, p0, LD/s;->h:Ljava/lang/Object;

    check-cast p1, Ln/q;

    invoke-virtual {p1, p3}, Ln/q;->a(I)V

    iget-object p1, p0, LD/s;->i:Ljava/lang/Object;

    check-cast p1, Ln/q;

    invoke-virtual {p1, p4}, Ln/q;->a(I)V

    goto :goto_0

    :cond_0
    iget-object p2, p0, LD/s;->d:Ljava/lang/Object;

    check-cast p2, Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_0
    return-void
.end method

.method public i(ILF/d;LF/d;LP/k;Z)V
    .locals 29

    move-object/from16 v7, p0

    move/from16 v8, p1

    move-object/from16 v9, p2

    move-object/from16 v10, p3

    iget-object v0, v7, LD/s;->i:Ljava/lang/Object;

    check-cast v0, Ln0/S;

    if-nez v0, :cond_0

    new-instance v11, Ln0/S;

    move-object v0, v11

    move-object/from16 v1, p0

    move-object/from16 v2, p4

    move/from16 v3, p1

    move-object/from16 v4, p2

    move-object/from16 v5, p3

    move/from16 v6, p5

    invoke-direct/range {v0 .. v6}, Ln0/S;-><init>(LD/s;LP/k;ILF/d;LF/d;Z)V

    iput-object v11, v7, LD/s;->i:Ljava/lang/Object;

    goto :goto_0

    :cond_0
    move-object/from16 v1, p4

    iput-object v1, v0, Ln0/S;->a:LP/k;

    iput v8, v0, Ln0/S;->b:I

    iput-object v9, v0, Ln0/S;->c:LF/d;

    iput-object v10, v0, Ln0/S;->d:LF/d;

    move/from16 v1, p5

    iput-boolean v1, v0, Ln0/S;->e:Z

    :goto_0
    iget v1, v9, LF/d;->f:I

    sub-int/2addr v1, v8

    iget v2, v10, LF/d;->f:I

    sub-int/2addr v2, v8

    add-int v3, v1, v2

    const/4 v4, 0x1

    add-int/2addr v3, v4

    const/4 v5, 0x2

    div-int/2addr v3, v5

    new-instance v6, LD/M;

    mul-int/lit8 v8, v3, 0x3

    invoke-direct {v6, v8}, LD/M;-><init>(I)V

    new-instance v8, LD/M;

    mul-int/lit8 v9, v3, 0x4

    invoke-direct {v8, v9}, LD/M;-><init>(I)V

    const/4 v9, 0x0

    invoke-virtual {v8, v9, v1, v9, v2}, LD/M;->d(IIII)V

    mul-int/2addr v3, v5

    add-int/2addr v3, v4

    new-array v10, v3, [I

    new-array v11, v3, [I

    const/4 v12, 0x5

    new-array v12, v12, [I

    :goto_1
    iget v13, v8, LD/M;->b:I

    if-eqz v13, :cond_1b

    iget-object v15, v8, LD/M;->a:[I

    add-int/lit8 v14, v13, -0x1

    iput v14, v8, LD/M;->b:I

    aget v14, v15, v14

    add-int/lit8 v9, v13, -0x2

    iput v9, v8, LD/M;->b:I

    aget v9, v15, v9

    add-int/lit8 v5, v13, -0x3

    iput v5, v8, LD/M;->b:I

    aget v5, v15, v5

    add-int/lit8 v13, v13, -0x4

    iput v13, v8, LD/M;->b:I

    aget v13, v15, v13

    sub-int v15, v5, v13

    sub-int v7, v14, v9

    if-lt v15, v4, :cond_1

    if-ge v7, v4, :cond_2

    :cond_1
    move/from16 v23, v1

    move/from16 v24, v2

    move/from16 p5, v3

    goto/16 :goto_14

    :cond_2
    add-int v16, v15, v7

    add-int/lit8 v16, v16, 0x1

    const/16 v17, 0x2

    div-int/lit8 v4, v16, 0x2

    div-int/lit8 v16, v3, 0x2

    add-int/lit8 v17, v16, 0x1

    aput v13, v10, v17

    aput v5, v11, v17

    move/from16 p5, v3

    const/4 v3, 0x0

    :goto_2
    if-ge v3, v4, :cond_1a

    sub-int v17, v15, v7

    invoke-static/range {v17 .. v17}, Ljava/lang/Math;->abs(I)I

    move-result v18

    move/from16 v20, v4

    const/16 v19, 0x2

    rem-int/lit8 v4, v18, 0x2

    move/from16 v18, v7

    const/4 v7, 0x1

    if-ne v4, v7, :cond_3

    const/4 v4, 0x1

    goto :goto_3

    :cond_3
    const/4 v4, 0x0

    :goto_3
    neg-int v7, v3

    move/from16 v19, v15

    move v15, v7

    :goto_4
    const/16 v21, 0x4

    if-gt v15, v3, :cond_c

    if-eq v15, v7, :cond_6

    if-eq v15, v3, :cond_4

    add-int/lit8 v22, v15, 0x1

    add-int v22, v22, v16

    move/from16 v23, v1

    aget v1, v10, v22

    add-int/lit8 v22, v15, -0x1

    add-int v22, v22, v16

    move/from16 v24, v2

    aget v2, v10, v22

    if-le v1, v2, :cond_5

    goto :goto_5

    :cond_4
    move/from16 v23, v1

    move/from16 v24, v2

    :cond_5
    add-int/lit8 v1, v15, -0x1

    add-int v1, v1, v16

    aget v1, v10, v1

    add-int/lit8 v2, v1, 0x1

    goto :goto_6

    :cond_6
    move/from16 v23, v1

    move/from16 v24, v2

    :goto_5
    add-int/lit8 v1, v15, 0x1

    add-int v1, v1, v16

    aget v1, v10, v1

    move v2, v1

    :goto_6
    sub-int v22, v2, v13

    add-int v22, v22, v9

    sub-int v22, v22, v15

    if-eqz v3, :cond_8

    if-eq v2, v1, :cond_7

    goto :goto_7

    :cond_7
    add-int/lit8 v25, v22, -0x1

    goto :goto_8

    :cond_8
    :goto_7
    move/from16 v25, v22

    :goto_8
    move/from16 v28, v22

    move-object/from16 v22, v8

    move/from16 v8, v28

    :goto_9
    if-ge v2, v5, :cond_9

    if-ge v8, v14, :cond_9

    invoke-virtual {v0, v2, v8}, Ln0/S;->a(II)Z

    move-result v26

    if-eqz v26, :cond_9

    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v8, v8, 0x1

    goto :goto_9

    :cond_9
    add-int v26, v16, v15

    aput v2, v10, v26

    move/from16 v26, v4

    if-eqz v4, :cond_a

    sub-int v4, v17, v15

    move-object/from16 v27, v6

    add-int/lit8 v6, v7, 0x1

    if-lt v4, v6, :cond_b

    add-int/lit8 v6, v3, -0x1

    if-gt v4, v6, :cond_b

    add-int v4, v16, v4

    aget v4, v11, v4

    if-gt v4, v2, :cond_b

    const/4 v4, 0x0

    aput v1, v12, v4

    const/4 v1, 0x1

    aput v25, v12, v1

    const/4 v1, 0x2

    aput v2, v12, v1

    const/4 v1, 0x3

    aput v8, v12, v1

    aput v4, v12, v21

    move/from16 v25, v5

    move/from16 v26, v14

    const/4 v1, 0x1

    const/4 v2, 0x3

    goto/16 :goto_10

    :cond_a
    move-object/from16 v27, v6

    :cond_b
    add-int/lit8 v15, v15, 0x2

    move-object/from16 v8, v22

    move/from16 v1, v23

    move/from16 v2, v24

    move/from16 v4, v26

    move-object/from16 v6, v27

    goto/16 :goto_4

    :cond_c
    move/from16 v23, v1

    move/from16 v24, v2

    move-object/from16 v27, v6

    move-object/from16 v22, v8

    rem-int/lit8 v1, v17, 0x2

    if-nez v1, :cond_d

    const/4 v1, 0x1

    goto :goto_a

    :cond_d
    const/4 v1, 0x0

    :goto_a
    move v2, v7

    :goto_b
    if-gt v2, v3, :cond_19

    if-eq v2, v7, :cond_f

    if-eq v2, v3, :cond_e

    add-int/lit8 v4, v2, 0x1

    add-int v4, v4, v16

    aget v4, v11, v4

    add-int/lit8 v6, v2, -0x1

    add-int v6, v6, v16

    aget v6, v11, v6

    if-ge v4, v6, :cond_e

    goto :goto_c

    :cond_e
    add-int/lit8 v4, v2, -0x1

    add-int v4, v4, v16

    aget v4, v11, v4

    add-int/lit8 v6, v4, -0x1

    goto :goto_d

    :cond_f
    :goto_c
    add-int/lit8 v4, v2, 0x1

    add-int v4, v4, v16

    aget v4, v11, v4

    move v6, v4

    :goto_d
    sub-int v8, v5, v6

    sub-int/2addr v8, v2

    sub-int v8, v14, v8

    if-eqz v3, :cond_11

    if-eq v6, v4, :cond_10

    goto :goto_e

    :cond_10
    add-int/lit8 v15, v8, 0x1

    goto :goto_f

    :cond_11
    :goto_e
    move v15, v8

    :goto_f
    if-le v6, v13, :cond_12

    if-le v8, v9, :cond_12

    move/from16 v25, v5

    add-int/lit8 v5, v6, -0x1

    move/from16 v26, v14

    add-int/lit8 v14, v8, -0x1

    invoke-virtual {v0, v5, v14}, Ln0/S;->a(II)Z

    move-result v5

    if-eqz v5, :cond_13

    add-int/lit8 v6, v6, -0x1

    add-int/lit8 v8, v8, -0x1

    move/from16 v5, v25

    move/from16 v14, v26

    goto :goto_f

    :cond_12
    move/from16 v25, v5

    move/from16 v26, v14

    :cond_13
    add-int v5, v16, v2

    aput v6, v11, v5

    if-eqz v1, :cond_18

    sub-int v5, v17, v2

    if-lt v5, v7, :cond_18

    if-gt v5, v3, :cond_18

    add-int v5, v16, v5

    aget v5, v10, v5

    if-lt v5, v6, :cond_18

    const/4 v5, 0x0

    aput v6, v12, v5

    const/4 v1, 0x1

    aput v8, v12, v1

    const/4 v2, 0x2

    aput v4, v12, v2

    const/4 v2, 0x3

    aput v15, v12, v2

    aput v1, v12, v21

    :goto_10
    invoke-static {v12}, Ln0/C;->j([I)I

    move-result v3

    if-lez v3, :cond_17

    aget v3, v12, v2

    aget v2, v12, v1

    sub-int/2addr v3, v2

    const/4 v1, 0x2

    aget v4, v12, v1

    const/4 v1, 0x0

    aget v5, v12, v1

    sub-int/2addr v4, v5

    if-eq v3, v4, :cond_16

    aget v1, v12, v21

    if-eqz v1, :cond_14

    invoke-static {v12}, Ln0/C;->j([I)I

    move-result v1

    move-object/from16 v6, v27

    invoke-virtual {v6, v5, v2, v1}, LD/M;->c(III)V

    goto :goto_11

    :cond_14
    move-object/from16 v6, v27

    if-le v3, v4, :cond_15

    add-int/lit8 v2, v2, 0x1

    invoke-static {v12}, Ln0/C;->j([I)I

    move-result v1

    invoke-virtual {v6, v5, v2, v1}, LD/M;->c(III)V

    goto :goto_11

    :cond_15
    add-int/lit8 v5, v5, 0x1

    invoke-static {v12}, Ln0/C;->j([I)I

    move-result v1

    invoke-virtual {v6, v5, v2, v1}, LD/M;->c(III)V

    goto :goto_11

    :cond_16
    move-object/from16 v6, v27

    invoke-virtual {v6, v5, v2, v4}, LD/M;->c(III)V

    :goto_11
    const/4 v1, 0x0

    goto :goto_12

    :cond_17
    move-object/from16 v6, v27

    goto :goto_11

    :goto_12
    aget v2, v12, v1

    const/4 v1, 0x1

    aget v3, v12, v1

    move-object/from16 v4, v22

    invoke-virtual {v4, v13, v2, v9, v3}, LD/M;->d(IIII)V

    const/4 v1, 0x2

    aget v2, v12, v1

    const/4 v1, 0x3

    aget v1, v12, v1

    move/from16 v8, v25

    move/from16 v5, v26

    invoke-virtual {v4, v2, v8, v1, v5}, LD/M;->d(IIII)V

    :goto_13
    const/4 v5, 0x2

    move-object/from16 v7, p0

    move/from16 v3, p5

    move-object v8, v4

    move/from16 v1, v23

    move/from16 v2, v24

    const/4 v9, 0x0

    const/4 v4, 0x1

    goto/16 :goto_1

    :cond_18
    move-object/from16 v4, v22

    move/from16 v8, v25

    move/from16 v5, v26

    move-object/from16 v6, v27

    add-int/lit8 v2, v2, 0x2

    move-object/from16 v22, v4

    move v14, v5

    move-object/from16 v27, v6

    move v5, v8

    goto/16 :goto_b

    :cond_19
    move v8, v5

    move v5, v14

    move-object/from16 v4, v22

    move-object/from16 v6, v27

    add-int/lit8 v3, v3, 0x1

    move v5, v8

    move/from16 v7, v18

    move/from16 v15, v19

    move/from16 v1, v23

    move/from16 v2, v24

    move-object v8, v4

    move/from16 v4, v20

    goto/16 :goto_2

    :cond_1a
    move/from16 v23, v1

    move/from16 v24, v2

    :goto_14
    move-object v4, v8

    goto :goto_13

    :cond_1b
    move/from16 v23, v1

    move/from16 v24, v2

    iget v1, v6, LD/M;->b:I

    rem-int/lit8 v2, v1, 0x3

    if-nez v2, :cond_27

    const/4 v2, 0x3

    if-le v1, v2, :cond_1c

    sub-int/2addr v1, v2

    const/4 v4, 0x0

    invoke-virtual {v6, v4, v1}, LD/M;->e(II)V

    :goto_15
    move/from16 v1, v23

    move/from16 v2, v24

    goto :goto_16

    :cond_1c
    const/4 v4, 0x0

    goto :goto_15

    :goto_16
    invoke-virtual {v6, v1, v2, v4}, LD/M;->c(III)V

    move v1, v4

    move v2, v1

    move v3, v2

    :cond_1d
    iget v5, v6, LD/M;->b:I

    if-ge v1, v5, :cond_25

    iget-object v5, v6, LD/M;->a:[I

    aget v7, v5, v1

    add-int/lit8 v8, v1, 0x2

    aget v8, v5, v8

    sub-int/2addr v7, v8

    add-int/lit8 v9, v1, 0x1

    aget v5, v5, v9

    sub-int/2addr v5, v8

    add-int/lit8 v1, v1, 0x3

    :goto_17
    iget-object v9, v0, Ln0/S;->f:LD/s;

    if-ge v2, v7, :cond_20

    iget-object v10, v0, Ln0/S;->a:LP/k;

    iget-object v10, v10, LP/k;->i:LP/k;

    invoke-static {v10}, Lp2/g;->b(Ljava/lang/Object;)V

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    iget v11, v10, LP/k;->f:I

    const/4 v12, 0x2

    and-int/2addr v11, v12

    if-eqz v11, :cond_1f

    iget-object v11, v10, LP/k;->k:Ln0/Y;

    invoke-static {v11}, Lp2/g;->b(Ljava/lang/Object;)V

    iget-object v13, v11, Ln0/Y;->p:Ln0/Y;

    iget-object v11, v11, Ln0/Y;->o:Ln0/Y;

    invoke-static {v11}, Lp2/g;->b(Ljava/lang/Object;)V

    if-nez v13, :cond_1e

    goto :goto_18

    :cond_1e
    iput-object v11, v13, Ln0/Y;->o:Ln0/Y;

    :goto_18
    iput-object v13, v11, Ln0/Y;->p:Ln0/Y;

    iget-object v13, v0, Ln0/S;->a:LP/k;

    invoke-static {v9, v13, v11}, LD/s;->a(LD/s;LP/k;Ln0/Y;)V

    :cond_1f
    invoke-static {v10}, LD/s;->c(LP/k;)LP/k;

    move-result-object v9

    iput-object v9, v0, Ln0/S;->a:LP/k;

    add-int/lit8 v2, v2, 0x1

    goto :goto_17

    :cond_20
    const/4 v12, 0x2

    :goto_19
    if-ge v3, v5, :cond_23

    iget v7, v0, Ln0/S;->b:I

    add-int/2addr v7, v3

    iget-object v10, v0, Ln0/S;->a:LP/k;

    iget-object v11, v0, Ln0/S;->d:LF/d;

    iget-object v11, v11, LF/d;->d:[Ljava/lang/Object;

    aget-object v7, v11, v7

    check-cast v7, LP/j;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7, v10}, LD/s;->b(LP/j;LP/k;)LP/k;

    move-result-object v7

    iput-object v7, v0, Ln0/S;->a:LP/k;

    iget-boolean v10, v0, Ln0/S;->e:Z

    if-eqz v10, :cond_22

    iget-object v7, v7, LP/k;->i:LP/k;

    invoke-static {v7}, Lp2/g;->b(Ljava/lang/Object;)V

    iget-object v7, v7, LP/k;->k:Ln0/Y;

    invoke-static {v7}, Lp2/g;->b(Ljava/lang/Object;)V

    iget-object v10, v0, Ln0/S;->a:LP/k;

    invoke-static {v10}, Ln0/C;->f(LP/k;)Ln0/s;

    move-result-object v10

    if-eqz v10, :cond_21

    new-instance v11, Ln0/u;

    iget-object v13, v9, LD/s;->b:Ljava/lang/Object;

    check-cast v13, Ln0/z;

    invoke-direct {v11, v13, v10}, Ln0/u;-><init>(Ln0/z;Ln0/s;)V

    iget-object v10, v0, Ln0/S;->a:LP/k;

    invoke-virtual {v10, v11}, LP/k;->e0(Ln0/Y;)V

    iget-object v10, v0, Ln0/S;->a:LP/k;

    invoke-static {v9, v10, v11}, LD/s;->a(LD/s;LP/k;Ln0/Y;)V

    iget-object v10, v7, Ln0/Y;->p:Ln0/Y;

    iput-object v10, v11, Ln0/Y;->p:Ln0/Y;

    iput-object v7, v11, Ln0/Y;->o:Ln0/Y;

    iput-object v11, v7, Ln0/Y;->p:Ln0/Y;

    goto :goto_1a

    :cond_21
    iget-object v10, v0, Ln0/S;->a:LP/k;

    invoke-virtual {v10, v7}, LP/k;->e0(Ln0/Y;)V

    :goto_1a
    iget-object v7, v0, Ln0/S;->a:LP/k;

    invoke-virtual {v7}, LP/k;->W()V

    iget-object v7, v0, Ln0/S;->a:LP/k;

    invoke-virtual {v7}, LP/k;->b0()V

    iget-object v7, v0, Ln0/S;->a:LP/k;

    invoke-static {v7}, Ln0/Z;->a(LP/k;)V

    const/4 v10, 0x1

    goto :goto_1b

    :cond_22
    const/4 v10, 0x1

    iput-boolean v10, v7, LP/k;->l:Z

    :goto_1b
    add-int/lit8 v3, v3, 0x1

    goto :goto_19

    :cond_23
    const/4 v10, 0x1

    :goto_1c
    add-int/lit8 v5, v8, -0x1

    if-lez v8, :cond_1d

    iget-object v7, v0, Ln0/S;->a:LP/k;

    iget-object v7, v7, LP/k;->i:LP/k;

    invoke-static {v7}, Lp2/g;->b(Ljava/lang/Object;)V

    iput-object v7, v0, Ln0/S;->a:LP/k;

    iget-object v7, v0, Ln0/S;->c:LF/d;

    iget v8, v0, Ln0/S;->b:I

    add-int v11, v8, v2

    iget-object v7, v7, LF/d;->d:[Ljava/lang/Object;

    aget-object v7, v7, v11

    check-cast v7, LP/j;

    iget-object v11, v0, Ln0/S;->d:LF/d;

    add-int/2addr v8, v3

    iget-object v11, v11, LF/d;->d:[Ljava/lang/Object;

    aget-object v8, v11, v8

    check-cast v8, LP/j;

    invoke-static {v7, v8}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v11

    if-nez v11, :cond_24

    iget-object v11, v0, Ln0/S;->a:LP/k;

    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-static {v7, v8, v11}, LD/s;->k(LP/j;LP/j;LP/k;)V

    goto :goto_1d

    :cond_24
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_1d
    add-int/lit8 v2, v2, 0x1

    add-int/lit8 v3, v3, 0x1

    move v8, v5

    goto :goto_1c

    :cond_25
    move-object/from16 v1, p0

    iget-object v0, v1, LD/s;->e:Ljava/lang/Object;

    check-cast v0, Ln0/m0;

    iget-object v0, v0, LP/k;->h:LP/k;

    move v9, v4

    :goto_1e
    if-eqz v0, :cond_26

    sget-object v2, Ln0/U;->a:Ln0/T;

    if-eq v0, v2, :cond_26

    iget v2, v0, LP/k;->f:I

    or-int/2addr v9, v2

    iput v9, v0, LP/k;->g:I

    iget-object v0, v0, LP/k;->h:LP/k;

    goto :goto_1e

    :cond_26
    return-void

    :cond_27
    move-object/from16 v1, p0

    const-string v0, "Array size not a multiple of 3"

    invoke-static {v0}, LZ0/d;->S(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method

.method public j()V
    .locals 5

    iget-object v0, p0, LD/s;->e:Ljava/lang/Object;

    check-cast v0, Ln0/m0;

    iget-object v0, v0, LP/k;->h:LP/k;

    iget-object v1, p0, LD/s;->c:Ljava/lang/Object;

    check-cast v1, Ln0/p;

    :goto_0
    iget-object v2, p0, LD/s;->b:Ljava/lang/Object;

    check-cast v2, Ln0/z;

    if-eqz v0, :cond_3

    invoke-static {v0}, Ln0/C;->f(LP/k;)Ln0/s;

    move-result-object v3

    if-eqz v3, :cond_2

    iget-object v4, v0, LP/k;->k:Ln0/Y;

    if-eqz v4, :cond_0

    check-cast v4, Ln0/u;

    iget-object v2, v4, Ln0/u;->K:Ln0/s;

    invoke-virtual {v4, v3}, Ln0/u;->M0(Ln0/s;)V

    if-eq v2, v0, :cond_1

    iget-object v2, v4, Ln0/Y;->F:Ln0/d0;

    if-eqz v2, :cond_1

    invoke-interface {v2}, Ln0/d0;->invalidate()V

    goto :goto_1

    :cond_0
    new-instance v4, Ln0/u;

    invoke-direct {v4, v2, v3}, Ln0/u;-><init>(Ln0/z;Ln0/s;)V

    invoke-virtual {v0, v4}, LP/k;->e0(Ln0/Y;)V

    :cond_1
    :goto_1
    iput-object v4, v1, Ln0/Y;->p:Ln0/Y;

    iput-object v1, v4, Ln0/Y;->o:Ln0/Y;

    move-object v1, v4

    goto :goto_2

    :cond_2
    invoke-virtual {v0, v1}, LP/k;->e0(Ln0/Y;)V

    :goto_2
    iget-object v0, v0, LP/k;->h:LP/k;

    goto :goto_0

    :cond_3
    invoke-virtual {v2}, Ln0/z;->k()Ln0/z;

    move-result-object v0

    if-eqz v0, :cond_4

    iget-object v0, v0, Ln0/z;->x:LD/s;

    iget-object v0, v0, LD/s;->c:Ljava/lang/Object;

    check-cast v0, Ln0/p;

    goto :goto_3

    :cond_4
    const/4 v0, 0x0

    :goto_3
    iput-object v0, v1, Ln0/Y;->p:Ln0/Y;

    iput-object v1, p0, LD/s;->d:Ljava/lang/Object;

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    iget v0, p0, LD/s;->a:I

    packed-switch v0, :pswitch_data_0

    invoke-super {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0

    :pswitch_0
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "["

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, LD/s;->f:Ljava/lang/Object;

    check-cast v1, LP/k;

    iget-object v2, p0, LD/s;->e:Ljava/lang/Object;

    check-cast v2, Ln0/m0;

    const-string v3, "]"

    if-ne v1, v2, :cond_0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_0
    :goto_0
    if-eqz v1, :cond_2

    if-eq v1, v2, :cond_2

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v4, v1, LP/k;->i:LP/k;

    if-ne v4, v2, :cond_1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    goto :goto_1

    :cond_1
    const-string v4, ","

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v1, LP/k;->i:LP/k;

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v1, "StringBuilder().apply(builderAction).toString()"

    invoke-static {v0, v1}, Lp2/g;->d(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_0
    .end packed-switch
.end method
