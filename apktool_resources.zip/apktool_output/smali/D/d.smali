.class public final LD/d;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final a:LD/a0;

.field public static final b:LD/a0;

.field public static final c:LD/a0;

.field public static final d:LD/a0;

.field public static final e:LD/a0;

.field public static final f:LD/o;

.field public static final g:Ljava/lang/Object;

.field public static final h:LD/G;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 2

    new-instance v0, LD/a0;

    const-string v1, "provider"

    invoke-direct {v0, v1}, LD/a0;-><init>(Ljava/lang/String;)V

    sput-object v0, LD/d;->a:LD/a0;

    new-instance v0, LD/a0;

    invoke-direct {v0, v1}, LD/a0;-><init>(Ljava/lang/String;)V

    sput-object v0, LD/d;->b:LD/a0;

    new-instance v0, LD/a0;

    const-string v1, "compositionLocalMap"

    invoke-direct {v0, v1}, LD/a0;-><init>(Ljava/lang/String;)V

    sput-object v0, LD/d;->c:LD/a0;

    new-instance v0, LD/a0;

    const-string v1, "providers"

    invoke-direct {v0, v1}, LD/a0;-><init>(Ljava/lang/String;)V

    sput-object v0, LD/d;->d:LD/a0;

    new-instance v0, LD/a0;

    const-string v1, "reference"

    invoke-direct {v0, v1}, LD/a0;-><init>(Ljava/lang/String;)V

    sput-object v0, LD/d;->e:LD/a0;

    new-instance v0, LD/o;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, LD/o;-><init>(I)V

    sput-object v0, LD/d;->f:LD/o;

    new-instance v0, Ljava/lang/Object;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD/d;->g:Ljava/lang/Object;

    new-instance v0, LD/G;

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    sput-object v0, LD/d;->h:LD/G;

    return-void
.end method

.method public static A(Ljava/lang/Object;)LD/f0;
    .locals 2

    sget-object v0, LD/U;->i:LD/U;

    sget v1, LD/b;->b:I

    new-instance v1, LD/f0;

    invoke-direct {v1, p0, v0}, LD/f0;-><init>(Ljava/lang/Object;LD/H0;)V

    return-object v1
.end method

.method public static final B(LD/j0;LD/k0;)Ljava/lang/Object;
    .locals 1

    const-string v0, "null cannot be cast to non-null type androidx.compose.runtime.CompositionLocal<kotlin.Any?>"

    invoke-static {p1, v0}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast p0, LL/e;

    invoke-virtual {p0, p1}, LL/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    if-nez v0, :cond_0

    iget-object v0, p1, LD/k0;->a:LD/T;

    :cond_0
    check-cast v0, LD/O0;

    invoke-interface {v0, p0}, LD/O0;->a(LD/j0;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static final C(Ljava/lang/Object;LD/n;)LD/Z;
    .locals 2

    invoke-virtual {p1}, LD/n;->H()Ljava/lang/Object;

    move-result-object v0

    sget-object v1, LD/l;->a:LD/U;

    if-ne v0, v1, :cond_0

    invoke-static {p0}, LD/d;->A(Ljava/lang/Object;)LD/f0;

    move-result-object v0

    invoke-virtual {p1, v0}, LD/n;->V(Ljava/lang/Object;)V

    :cond_0
    check-cast v0, LD/Z;

    invoke-interface {v0, p0}, LD/Z;->setValue(Ljava/lang/Object;)V

    return-object v0
.end method

.method public static final D(LD/D0;LD/s;)V
    .locals 9

    iget v0, p0, LD/D0;->s:I

    invoke-virtual {p0, v0}, LD/D0;->p(I)I

    move-result v0

    iget-object v1, p0, LD/D0;->b:[I

    invoke-virtual {p0, v1, v0}, LD/D0;->f([II)I

    move-result v0

    iget-object v1, p0, LD/D0;->b:[I

    iget v2, p0, LD/D0;->s:I

    invoke-virtual {p0, v2}, LD/D0;->q(I)I

    move-result v3

    add-int/2addr v3, v2

    invoke-virtual {p0, v3}, LD/D0;->p(I)I

    move-result v2

    invoke-virtual {p0, v1, v2}, LD/D0;->f([II)I

    move-result v1

    :goto_0
    if-ge v0, v1, :cond_5

    iget-object v2, p0, LD/D0;->c:[Ljava/lang/Object;

    invoke-virtual {p0, v0}, LD/D0;->g(I)I

    move-result v3

    aget-object v2, v2, v3

    instance-of v3, v2, Ln0/z;

    const/4 v4, -0x1

    if-eqz v3, :cond_1

    invoke-virtual {p0}, LD/D0;->o()I

    move-result v3

    sub-int/2addr v3, v0

    move-object v5, v2

    check-cast v5, Ln0/z;

    iget-object v6, p1, LD/s;->g:Ljava/lang/Object;

    check-cast v6, Ln/B;

    if-nez v6, :cond_0

    sget v6, Ln/E;->a:I

    new-instance v6, Ln/B;

    invoke-direct {v6}, Ln/B;-><init>()V

    iput-object v6, p1, LD/s;->g:Ljava/lang/Object;

    :cond_0
    invoke-virtual {v6, v5}, Ln/B;->d(Ljava/lang/Object;)I

    move-result v7

    iget-object v6, v6, Ln/B;->b:[Ljava/lang/Object;

    aput-object v5, v6, v7

    invoke-virtual {p1, v5, v3, v4, v4}, LD/s;->h(Ljava/lang/Object;III)V

    :cond_1
    instance-of v3, v2, LD/x0;

    if-eqz v3, :cond_3

    invoke-virtual {p0}, LD/D0;->o()I

    move-result v3

    sub-int/2addr v3, v0

    move-object v5, v2

    check-cast v5, LD/x0;

    iget-object v6, v5, LD/x0;->b:LD/c;

    if-eqz v6, :cond_2

    invoke-virtual {v6}, LD/c;->a()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-virtual {p0, v6}, LD/D0;->c(LD/c;)I

    move-result v4

    invoke-virtual {p0}, LD/D0;->o()I

    move-result v6

    iget-object v7, p0, LD/D0;->b:[I

    invoke-virtual {p0, v4}, LD/D0;->q(I)I

    move-result v8

    add-int/2addr v8, v4

    invoke-virtual {p0, v8}, LD/D0;->p(I)I

    move-result v8

    invoke-virtual {p0, v7, v8}, LD/D0;->f([II)I

    move-result v7

    sub-int/2addr v6, v7

    goto :goto_1

    :cond_2
    move v6, v4

    :goto_1
    iget-object v5, v5, LD/x0;->a:LD/w0;

    invoke-virtual {p1, v5, v3, v4, v6}, LD/s;->h(Ljava/lang/Object;III)V

    :cond_3
    instance-of v3, v2, LD/n0;

    if-eqz v3, :cond_4

    check-cast v2, LD/n0;

    invoke-virtual {v2}, LD/n0;->d()V

    :cond_4
    add-int/lit8 v0, v0, 0x1

    goto :goto_0

    :cond_5
    invoke-virtual {p0}, LD/D0;->y()Z

    return-void
.end method

.method public static final E(Z)V
    .locals 0

    if-eqz p0, :cond_0

    return-void

    :cond_0
    const-string p0, "Check failed"

    invoke-static {p0}, LD/d;->r(Ljava/lang/String;)V

    const/4 p0, 0x0

    throw p0
.end method

.method public static final F(Ljava/util/ArrayList;II)I
    .locals 4

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    :goto_0
    if-gt v1, v0, :cond_3

    add-int v2, v1, v0

    ushr-int/lit8 v2, v2, 0x1

    invoke-virtual {p0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LD/c;

    iget v3, v3, LD/c;->a:I

    if-gez v3, :cond_0

    add-int/2addr v3, p2

    :cond_0
    invoke-static {v3, p1}, Lp2/g;->f(II)I

    move-result v3

    if-gez v3, :cond_1

    add-int/lit8 v1, v2, 0x1

    goto :goto_0

    :cond_1
    if-lez v3, :cond_2

    add-int/lit8 v0, v2, -0x1

    goto :goto_0

    :cond_2
    return v2

    :cond_3
    add-int/lit8 v1, v1, 0x1

    neg-int p0, v1

    return p0
.end method

.method public static final G(LD/n;Ljava/lang/Object;Lo2/e;)V
    .locals 1

    iget-boolean v0, p0, LD/n;->L:Z

    if-nez v0, :cond_0

    invoke-virtual {p0}, LD/n;->H()Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0, p1}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_1

    :cond_0
    invoke-virtual {p0, p1}, LD/n;->V(Ljava/lang/Object;)V

    invoke-virtual {p0, p1, p2}, LD/n;->b(Ljava/lang/Object;Lo2/e;)V

    :cond_1
    return-void
.end method

.method public static final H(Ljava/lang/String;)V
    .locals 1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final I(Ljava/lang/String;)V
    .locals 1

    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final J(I)I
    .locals 3

    const v0, 0x12492492

    and-int/2addr v0, p0

    const v1, 0x24924924

    and-int/2addr v1, p0

    const v2, -0x36db6db7

    and-int/2addr p0, v2

    shr-int/lit8 v2, v1, 0x1

    or-int/2addr v2, v0

    or-int/2addr p0, v2

    shl-int/lit8 v0, v0, 0x1

    and-int/2addr v0, v1

    or-int/2addr p0, v0

    return p0
.end method

.method public static final K([LD/l0;LD/j0;LD/j0;)LL/e;
    .locals 6

    sget-object v0, LL/e;->g:LL/e;

    new-instance v1, LL/d;

    invoke-direct {v1, v0}, LL/d;-><init>(LL/e;)V

    array-length v0, p0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_2

    aget-object v3, p0, v2

    iget-object v4, v3, LD/l0;->a:LD/k0;

    iget-boolean v5, v3, LD/l0;->f:Z

    if-nez v5, :cond_0

    move-object v5, p1

    check-cast v5, LL/e;

    invoke-virtual {v5, v4}, LL/e;->containsKey(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_1

    :cond_0
    move-object v5, p2

    check-cast v5, LL/e;

    invoke-virtual {v5, v4}, LL/e;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LD/O0;

    invoke-virtual {v4, v3, v5}, LD/k0;->b(LD/l0;LD/O0;)LD/O0;

    move-result-object v3

    invoke-virtual {v1, v4, v3}, LL/d;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_2
    invoke-virtual {v1}, LL/d;->a()LL/e;

    move-result-object p0

    return-object p0
.end method

.method public static final a(LD/l0;LL/a;LD/n;I)V
    .locals 10

    const v0, -0x50862cb8

    invoke-virtual {p2, v0}, LD/n;->O(I)LD/n;

    invoke-virtual {p2}, LD/n;->m()LD/j0;

    move-result-object v0

    sget-object v1, LD/d;->b:LD/a0;

    const/16 v2, 0xc9

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, v2, v1, v3, v4}, LD/n;->L(ILjava/lang/Object;ILD/j0;)V

    invoke-virtual {p2}, LD/n;->H()Ljava/lang/Object;

    move-result-object v1

    sget-object v2, LD/l;->a:LD/U;

    invoke-static {v1, v2}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    move-object v1, v4

    goto :goto_0

    :cond_0
    const-string v2, "null cannot be cast to non-null type androidx.compose.runtime.ValueHolder<kotlin.Any?>"

    invoke-static {v1, v2}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, LD/O0;

    :goto_0
    iget-object v2, p0, LD/l0;->a:LD/k0;

    invoke-virtual {v2, p0, v1}, LD/k0;->b(LD/l0;LD/O0;)LD/O0;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1

    invoke-virtual {p2, v5}, LD/n;->V(Ljava/lang/Object;)V

    :cond_1
    iget-boolean v6, p2, LD/n;->L:Z

    const/4 v7, 0x1

    if-eqz v6, :cond_6

    iget-boolean v1, p0, LD/l0;->f:Z

    if-nez v1, :cond_2

    move-object v1, v0

    check-cast v1, LL/e;

    invoke-virtual {v1, v2}, LL/e;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4

    :cond_2
    check-cast v0, LL/e;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    iget-object v6, v0, LI/c;->d:LI/n;

    invoke-virtual {v6, v1, v2, v5, v3}, LI/n;->u(ILjava/lang/Object;Ljava/lang/Object;I)LI/m;

    move-result-object v1

    if-nez v1, :cond_3

    goto :goto_1

    :cond_3
    new-instance v2, LL/e;

    iget-object v5, v1, LI/m;->f:Ljava/lang/Object;

    check-cast v5, LI/n;

    iget v0, v0, LI/c;->e:I

    iget v1, v1, LI/m;->e:I

    add-int/2addr v0, v1

    invoke-direct {v2, v5, v0}, LI/c;-><init>(LI/n;I)V

    move-object v0, v2

    :cond_4
    :goto_1
    iput-boolean v7, p2, LD/n;->G:Z

    :cond_5
    move v1, v3

    goto :goto_4

    :cond_6
    iget-object v6, p2, LD/n;->D:LD/A0;

    iget v8, v6, LD/A0;->g:I

    iget-object v9, v6, LD/A0;->b:[I

    invoke-virtual {v6, v9, v8}, LD/A0;->b([II)Ljava/lang/Object;

    move-result-object v6

    const-string v8, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    invoke-static {v6, v8}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, LD/j0;

    invoke-virtual {p2}, LD/n;->y()Z

    move-result v8

    if-eqz v8, :cond_7

    if-nez v1, :cond_8

    :cond_7
    iget-boolean v1, p0, LD/l0;->f:Z

    if-nez v1, :cond_9

    move-object v1, v0

    check-cast v1, LL/e;

    invoke-virtual {v1, v2}, LL/e;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_8

    goto :goto_2

    :cond_8
    move-object v0, v6

    goto :goto_3

    :cond_9
    :goto_2
    check-cast v0, LL/e;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    move-result v1

    iget-object v8, v0, LI/c;->d:LI/n;

    invoke-virtual {v8, v1, v2, v5, v3}, LI/n;->u(ILjava/lang/Object;Ljava/lang/Object;I)LI/m;

    move-result-object v1

    if-nez v1, :cond_a

    goto :goto_3

    :cond_a
    new-instance v2, LL/e;

    iget-object v5, v1, LI/m;->f:Ljava/lang/Object;

    check-cast v5, LI/n;

    iget v0, v0, LI/c;->e:I

    iget v1, v1, LI/m;->e:I

    add-int/2addr v0, v1

    invoke-direct {v2, v5, v0}, LI/c;-><init>(LI/n;I)V

    move-object v0, v2

    :goto_3
    if-eq v6, v0, :cond_5

    move v1, v7

    :goto_4
    if-eqz v1, :cond_b

    iget-boolean v2, p2, LD/n;->L:Z

    if-nez v2, :cond_b

    invoke-virtual {p2, v0}, LD/n;->F(LD/j0;)V

    :cond_b
    iget-boolean v2, p2, LD/n;->v:Z

    iget-object v5, p2, LD/n;->w:LD/M;

    invoke-virtual {v5, v2}, LD/M;->b(I)V

    iput-boolean v1, p2, LD/n;->v:Z

    iput-object v0, p2, LD/n;->H:LD/j0;

    sget-object v1, LD/d;->c:LD/a0;

    const/16 v2, 0xca

    invoke-virtual {p2, v2, v1, v3, v0}, LD/n;->L(ILjava/lang/Object;ILD/j0;)V

    shr-int/lit8 v0, p3, 0x3

    and-int/lit8 v0, v0, 0xe

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, LL/a;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2, v3}, LD/n;->q(Z)V

    invoke-virtual {p2, v3}, LD/n;->q(Z)V

    invoke-virtual {v5}, LD/M;->a()I

    move-result v0

    if-eqz v0, :cond_c

    move v3, v7

    :cond_c
    iput-boolean v3, p2, LD/n;->v:Z

    iput-object v4, p2, LD/n;->H:LD/j0;

    invoke-virtual {p2}, LD/n;->s()LD/n0;

    move-result-object p2

    if-eqz p2, :cond_d

    new-instance v0, LD/u;

    const/4 v1, 0x1

    invoke-direct {v0, p0, p1, p3, v1}, LD/u;-><init>(Ljava/lang/Object;LL/a;II)V

    iput-object v0, p2, LD/n0;->d:Lo2/e;

    :cond_d
    return-void
.end method

.method public static final b([LD/l0;LL/a;LD/n;I)V
    .locals 8

    const v0, -0x52e5dee3

    invoke-virtual {p2, v0}, LD/n;->O(I)LD/n;

    invoke-virtual {p2}, LD/n;->m()LD/j0;

    move-result-object v0

    sget-object v1, LD/d;->b:LD/a0;

    const/16 v2, 0xc9

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2, v2, v1, v3, v4}, LD/n;->L(ILjava/lang/Object;ILD/j0;)V

    iget-boolean v1, p2, LD/n;->L:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    sget-object v1, LL/e;->g:LL/e;

    invoke-static {p0, v0, v1}, LD/d;->K([LD/l0;LD/j0;LD/j0;)LL/e;

    move-result-object v1

    invoke-virtual {p2, v0, v1}, LD/n;->U(LD/j0;LL/e;)LL/e;

    move-result-object v0

    iput-boolean v2, p2, LD/n;->G:Z

    :goto_0
    move v1, v3

    goto :goto_2

    :cond_0
    iget-object v1, p2, LD/n;->D:LD/A0;

    iget v5, v1, LD/A0;->g:I

    invoke-virtual {v1, v5, v3}, LD/A0;->g(II)Ljava/lang/Object;

    move-result-object v1

    const-string v5, "null cannot be cast to non-null type androidx.compose.runtime.PersistentCompositionLocalMap"

    invoke-static {v1, v5}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v1, LD/j0;

    iget-object v6, p2, LD/n;->D:LD/A0;

    iget v7, v6, LD/A0;->g:I

    invoke-virtual {v6, v7, v2}, LD/A0;->g(II)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v6, v5}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    check-cast v6, LD/j0;

    invoke-static {p0, v0, v6}, LD/d;->K([LD/l0;LD/j0;LD/j0;)LL/e;

    move-result-object v5

    invoke-virtual {p2}, LD/n;->y()Z

    move-result v7

    if-eqz v7, :cond_2

    invoke-virtual {v6, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v6

    if-nez v6, :cond_1

    goto :goto_1

    :cond_1
    iget v0, p2, LD/n;->k:I

    iget-object v5, p2, LD/n;->D:LD/A0;

    invoke-virtual {v5}, LD/A0;->l()I

    move-result v5

    add-int/2addr v5, v0

    iput v5, p2, LD/n;->k:I

    move-object v0, v1

    goto :goto_0

    :cond_2
    :goto_1
    invoke-virtual {p2, v0, v5}, LD/n;->U(LD/j0;LL/e;)LL/e;

    move-result-object v0

    invoke-static {v0, v1}, Lp2/g;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    xor-int/2addr v1, v2

    :goto_2
    if-eqz v1, :cond_3

    iget-boolean v5, p2, LD/n;->L:Z

    if-nez v5, :cond_3

    invoke-virtual {p2, v0}, LD/n;->F(LD/j0;)V

    :cond_3
    iget-boolean v5, p2, LD/n;->v:Z

    iget-object v6, p2, LD/n;->w:LD/M;

    invoke-virtual {v6, v5}, LD/M;->b(I)V

    iput-boolean v1, p2, LD/n;->v:Z

    iput-object v0, p2, LD/n;->H:LD/j0;

    sget-object v1, LD/d;->c:LD/a0;

    const/16 v5, 0xca

    invoke-virtual {p2, v5, v1, v3, v0}, LD/n;->L(ILjava/lang/Object;ILD/j0;)V

    shr-int/lit8 v0, p3, 0x3

    and-int/lit8 v0, v0, 0xe

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p1, p2, v0}, LL/a;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {p2, v3}, LD/n;->q(Z)V

    invoke-virtual {p2, v3}, LD/n;->q(Z)V

    invoke-virtual {v6}, LD/M;->a()I

    move-result v0

    if-eqz v0, :cond_4

    move v3, v2

    :cond_4
    iput-boolean v3, p2, LD/n;->v:Z

    iput-object v4, p2, LD/n;->H:LD/j0;

    invoke-virtual {p2}, LD/n;->s()LD/n0;

    move-result-object p2

    if-eqz p2, :cond_5

    new-instance v0, LD/u;

    const/4 v1, 0x0

    invoke-direct {v0, p0, p1, p3, v1}, LD/u;-><init>(Ljava/lang/Object;LL/a;II)V

    iput-object v0, p2, LD/n0;->d:Lo2/e;

    :cond_5
    return-void
.end method

.method public static final c(Ljava/lang/Object;Lo2/c;LD/n;)V
    .locals 1

    invoke-virtual {p2, p0}, LD/n;->f(Ljava/lang/Object;)Z

    move-result p0

    invoke-virtual {p2}, LD/n;->H()Ljava/lang/Object;

    move-result-object v0

    if-nez p0, :cond_0

    sget-object p0, LD/l;->a:LD/U;

    if-ne v0, p0, :cond_1

    :cond_0
    new-instance v0, LD/E;

    invoke-direct {v0, p1}, LD/E;-><init>(Lo2/c;)V

    invoke-virtual {p2, v0}, LD/n;->V(Ljava/lang/Object;)V

    :cond_1
    check-cast v0, LD/E;

    return-void
.end method

.method public static final d(LD/n;Ljava/lang/Object;Lo2/e;)V
    .locals 2

    iget-object v0, p0, LD/n;->b:LD/q;

    check-cast v0, LD/v0;

    invoke-virtual {p0, p1}, LD/n;->f(Ljava/lang/Object;)Z

    move-result p1

    invoke-virtual {p0}, LD/n;->H()Ljava/lang/Object;

    move-result-object v1

    if-nez p1, :cond_0

    sget-object p1, LD/l;->a:LD/U;

    if-ne v1, p1, :cond_1

    :cond_0
    new-instance v1, LD/S;

    iget-object p1, v0, LD/v0;->t:Lg2/i;

    invoke-direct {v1, p1, p2}, LD/S;-><init>(Lg2/i;Lo2/e;)V

    invoke-virtual {p0, v1}, LD/n;->V(Ljava/lang/Object;)V

    :cond_1
    check-cast v1, LD/S;

    return-void
.end method

.method public static final e([II)Z
    .locals 1

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    aget p0, p0, p1

    const/high16 p1, 0x4000000

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static final f([II)I
    .locals 0

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x4

    aget p0, p0, p1

    return p0
.end method

.method public static final g([II)I
    .locals 0

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x3

    aget p0, p0, p1

    return p0
.end method

.method public static final h([II)Z
    .locals 1

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    aget p0, p0, p1

    const/high16 p1, 0x10000000

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static final i([II)Z
    .locals 1

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    aget p0, p0, p1

    const/high16 p1, 0x20000000

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static final j([II)Z
    .locals 1

    mul-int/lit8 p1, p1, 0x5

    const/4 v0, 0x1

    add-int/2addr p1, v0

    aget p0, p0, p1

    const/high16 p1, 0x40000000    # 2.0f

    and-int/2addr p0, p1

    if-eqz p0, :cond_0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public static final k(Ljava/util/ArrayList;II)I
    .locals 0

    invoke-static {p0, p1, p2}, LD/d;->F(Ljava/util/ArrayList;II)I

    move-result p0

    if-ltz p0, :cond_0

    goto :goto_0

    :cond_0
    add-int/lit8 p0, p0, 0x1

    neg-int p0, p0

    :goto_0
    return p0
.end method

.method public static final l([II)I
    .locals 0

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x1

    aget p0, p0, p1

    const p1, 0x3ffffff

    and-int/2addr p0, p1

    return p0
.end method

.method public static final m([II)I
    .locals 0

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 p1, p1, 0x2

    aget p0, p0, p1

    return p0
.end method

.method public static final n(Ljava/util/ArrayList;II)V
    .locals 1

    invoke-static {p1, p0}, LD/d;->w(ILjava/util/ArrayList;)I

    move-result p1

    if-gez p1, :cond_0

    add-int/lit8 p1, p1, 0x1

    neg-int p1, p1

    :cond_0
    :goto_0
    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    if-ge p1, v0, :cond_1

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, LD/N;

    iget v0, v0, LD/N;->b:I

    if-ge v0, p2, :cond_1

    invoke-virtual {p0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    return-void
.end method

.method public static final o([II)I
    .locals 1

    mul-int/lit8 p1, p1, 0x5

    add-int/lit8 v0, p1, 0x4

    aget v0, p0, v0

    add-int/lit8 p1, p1, 0x1

    aget p0, p0, p1

    shr-int/lit8 p0, p0, 0x1c

    invoke-static {p0}, LD/d;->t(I)I

    move-result p0

    add-int/2addr p0, v0

    return p0
.end method

.method public static final p(II[I)V
    .locals 1

    if-ltz p1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-static {v0}, LD/d;->E(Z)V

    mul-int/lit8 p0, p0, 0x5

    add-int/lit8 p0, p0, 0x3

    aput p1, p2, p0

    return-void
.end method

.method public static final q(II[I)V
    .locals 2

    const/4 v0, 0x1

    if-ltz p1, :cond_0

    const v1, 0x3ffffff

    if-ge p1, v1, :cond_0

    move v1, v0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    invoke-static {v1}, LD/d;->E(Z)V

    mul-int/lit8 p0, p0, 0x5

    add-int/2addr p0, v0

    aget v0, p2, p0

    const/high16 v1, -0x4000000

    and-int/2addr v0, v1

    or-int/2addr p1, v0

    aput p1, p2, p0

    return-void
.end method

.method public static final r(Ljava/lang/String;)V
    .locals 3

    new-instance v0, LD/k;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Compose Runtime internal error. Unexpected or incorrect use of the Compose internal runtime API ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "). Please report to Google or use https://goo.gle/compose-feedback"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, LD/k;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final s(Ljava/lang/String;)V
    .locals 3

    new-instance v0, LD/k;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "Compose Runtime internal error. Unexpected or incorrect use of the Compose internal runtime API ("

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, "). Please report to Google or use https://goo.gle/compose-feedback"

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-direct {v0, p0}, LD/k;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static final t(I)I
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x2

    packed-switch p0, :pswitch_data_0

    const/4 v0, 0x3

    goto :goto_0

    :pswitch_0
    move v0, v1

    goto :goto_0

    :pswitch_1
    const/4 v0, 0x0

    :goto_0
    :pswitch_2
    return v0

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_1
        :pswitch_2
        :pswitch_2
        :pswitch_0
        :pswitch_2
        :pswitch_0
        :pswitch_0
    .end packed-switch
.end method

.method public static final u()J
    .locals 2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    return-wide v0
.end method

.method public static final v()LF/d;
    .locals 3

    sget-object v0, LD/I0;->b:LB0/a;

    invoke-virtual {v0}, LB0/a;->i()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, LF/d;

    if-nez v1, :cond_0

    new-instance v1, LF/d;

    const/4 v2, 0x0

    new-array v2, v2, [LD/m;

    invoke-direct {v1, v2}, LF/d;-><init>([Ljava/lang/Object;)V

    invoke-virtual {v0, v1}, LB0/a;->E(Ljava/lang/Object;)V

    :cond_0
    return-object v1
.end method

.method public static final w(ILjava/util/ArrayList;)I
    .locals 4

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    const/4 v1, 0x0

    :goto_0
    if-gt v1, v0, :cond_2

    add-int v2, v1, v0

    ushr-int/lit8 v2, v2, 0x1

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, LD/N;

    iget v3, v3, LD/N;->b:I

    invoke-static {v3, p0}, Lp2/g;->f(II)I

    move-result v3

    if-gez v3, :cond_0

    add-int/lit8 v1, v2, 0x1

    goto :goto_0

    :cond_0
    if-lez v3, :cond_1

    add-int/lit8 v0, v2, -0x1

    goto :goto_0

    :cond_1
    return v2

    :cond_2
    add-int/lit8 v1, v1, 0x1

    neg-int p0, v1

    return p0
.end method

.method public static final x(Lg2/i;)LD/V;
    .locals 1

    sget-object v0, LD/U;->e:LD/U;

    invoke-interface {p0, v0}, Lg2/i;->n(Lg2/h;)Lg2/g;

    move-result-object p0

    check-cast p0, LD/V;

    if-eqz p0, :cond_0

    return-object p0

    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    const-string v0, "A MonotonicFrameClock is not available in this CoroutineContext. Callers should supply an appropriate MonotonicFrameClock using withContext."

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static final y(LD/n;Lo2/e;)V
    .locals 1

    const-string v0, "null cannot be cast to non-null type kotlin.Function2<androidx.compose.runtime.Composer, kotlin.Int, kotlin.Unit>"

    invoke-static {p1, v0}, Lp2/g;->c(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v0, 0x2

    invoke-static {v0, p1}, Lp2/r;->c(ILjava/lang/Object;)V

    const/4 v0, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {p1, p0, v0}, Lo2/e;->h(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.method public static z(LD/D0;ILD/D0;ZZZ)Ljava/util/List;
    .locals 21

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    invoke-virtual/range {p0 .. p1}, LD/D0;->q(I)I

    move-result v3

    add-int v4, v1, v3

    iget-object v5, v0, LD/D0;->b:[I

    invoke-virtual/range {p0 .. p1}, LD/D0;->p(I)I

    move-result v6

    invoke-virtual {v0, v5, v6}, LD/D0;->f([II)I

    move-result v5

    iget-object v6, v0, LD/D0;->b:[I

    invoke-virtual {v0, v4}, LD/D0;->p(I)I

    move-result v7

    invoke-virtual {v0, v6, v7}, LD/D0;->f([II)I

    move-result v6

    sub-int v7, v6, v5

    const/4 v8, 0x1

    if-ltz v1, :cond_0

    iget-object v10, v0, LD/D0;->b:[I

    invoke-virtual/range {p0 .. p1}, LD/D0;->p(I)I

    move-result v11

    mul-int/lit8 v11, v11, 0x5

    add-int/2addr v11, v8

    aget v10, v10, v11

    const/high16 v11, 0xc000000

    and-int/2addr v10, v11

    if-eqz v10, :cond_0

    move v10, v8

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    :goto_0
    invoke-virtual {v2, v3}, LD/D0;->r(I)V

    iget v11, v2, LD/D0;->s:I

    invoke-virtual {v2, v7, v11}, LD/D0;->s(II)V

    iget v11, v0, LD/D0;->g:I

    if-ge v11, v4, :cond_1

    invoke-virtual {v0, v4}, LD/D0;->u(I)V

    :cond_1
    iget v11, v0, LD/D0;->k:I

    if-ge v11, v6, :cond_2

    invoke-virtual {v0, v6, v4}, LD/D0;->v(II)V

    :cond_2
    iget-object v11, v2, LD/D0;->b:[I

    iget v12, v2, LD/D0;->s:I

    iget-object v13, v0, LD/D0;->b:[I

    mul-int/lit8 v14, v12, 0x5

    mul-int/lit8 v15, v1, 0x5

    mul-int/lit8 v9, v4, 0x5

    invoke-static {v14, v15, v9, v13, v11}, Ld2/j;->X(III[I[I)V

    iget-object v9, v2, LD/D0;->c:[Ljava/lang/Object;

    iget v13, v2, LD/D0;->i:I

    iget-object v15, v0, LD/D0;->c:[Ljava/lang/Object;

    invoke-static {v15, v9, v13, v5, v6}, Ld2/j;->Y([Ljava/lang/Object;[Ljava/lang/Object;III)V

    iget v6, v2, LD/D0;->u:I

    add-int/lit8 v14, v14, 0x2

    aput v6, v11, v14

    sub-int v14, v12, v1

    add-int v15, v12, v3

    invoke-virtual {v2, v11, v12}, LD/D0;->f([II)I

    move-result v16

    sub-int v16, v13, v16

    iget v8, v2, LD/D0;->m:I

    move/from16 v17, v8

    iget v8, v2, LD/D0;->l:I

    array-length v9, v9

    move/from16 v18, v10

    move/from16 v10, v17

    move/from16 v17, v13

    move v13, v12

    :goto_1
    if-ge v13, v15, :cond_6

    if-eq v13, v12, :cond_3

    mul-int/lit8 v19, v13, 0x5

    add-int/lit8 v19, v19, 0x2

    aget v20, v11, v19

    add-int v20, v20, v14

    aput v20, v11, v19

    :cond_3
    invoke-virtual {v2, v11, v13}, LD/D0;->f([II)I

    move-result v19

    move/from16 v20, v15

    add-int v15, v19, v16

    if-ge v10, v13, :cond_4

    move/from16 v19, v12

    const/4 v12, 0x0

    goto :goto_2

    :cond_4
    move/from16 v19, v12

    iget v12, v2, LD/D0;->k:I

    :goto_2
    invoke-static {v15, v12, v8, v9}, LD/D0;->h(IIII)I

    move-result v12

    mul-int/lit8 v15, v13, 0x5

    add-int/lit8 v15, v15, 0x4

    aput v12, v11, v15

    if-ne v13, v10, :cond_5

    add-int/lit8 v10, v10, 0x1

    :cond_5
    add-int/lit8 v13, v13, 0x1

    move/from16 v12, v19

    move/from16 v15, v20

    goto :goto_1

    :cond_6
    move/from16 v19, v12

    move/from16 v20, v15

    iput v10, v2, LD/D0;->m:I

    iget-object v8, v0, LD/D0;->d:Ljava/util/ArrayList;

    invoke-virtual/range {p0 .. p0}, LD/D0;->n()I

    move-result v9

    invoke-static {v8, v1, v9}, LD/d;->k(Ljava/util/ArrayList;II)I

    move-result v8

    iget-object v9, v0, LD/D0;->d:Ljava/util/ArrayList;

    invoke-virtual/range {p0 .. p0}, LD/D0;->n()I

    move-result v10

    invoke-static {v9, v4, v10}, LD/d;->k(Ljava/util/ArrayList;II)I

    move-result v4

    if-ge v8, v4, :cond_8

    iget-object v9, v0, LD/D0;->d:Ljava/util/ArrayList;

    new-instance v10, Ljava/util/ArrayList;

    sub-int v12, v4, v8

    invoke-direct {v10, v12}, Ljava/util/ArrayList;-><init>(I)V

    move v12, v8

    :goto_3
    if-ge v12, v4, :cond_7

    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, LD/c;

    iget v15, v13, LD/c;->a:I

    add-int/2addr v15, v14

    iput v15, v13, LD/c;->a:I

    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v12, v12, 0x1

    goto :goto_3

    :cond_7
    iget-object v12, v2, LD/D0;->d:Ljava/util/ArrayList;

    iget v13, v2, LD/D0;->s:I

    invoke-virtual/range {p2 .. p2}, LD/D0;->n()I

    move-result v14

    invoke-static {v12, v13, v14}, LD/d;->k(Ljava/util/ArrayList;II)I

    move-result v12

    iget-object v13, v2, LD/D0;->d:Ljava/util/ArrayList;

    invoke-virtual {v13, v12, v10}, Ljava/util/ArrayList;->addAll(ILjava/util/Collection;)Z

    invoke-virtual {v9, v8, v4}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v4

    invoke-interface {v4}, Ljava/util/List;->clear()V

    goto :goto_4

    :cond_8
    sget-object v10, Ld2/s;->d:Ld2/s;

    :goto_4
    invoke-interface {v10}, Ljava/util/Collection;->isEmpty()Z

    move-result v4

    if-nez v4, :cond_9

    iget-object v4, v0, LD/D0;->e:Ljava/util/HashMap;

    iget-object v8, v2, LD/D0;->e:Ljava/util/HashMap;

    if-eqz v4, :cond_9

    if-eqz v8, :cond_9

    invoke-interface {v10}, Ljava/util/List;->size()I

    move-result v8

    const/4 v9, 0x0

    :goto_5
    if-ge v9, v8, :cond_9

    invoke-interface {v10, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LD/c;

    invoke-virtual {v4, v12}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v12

    check-cast v12, LD/L;

    add-int/lit8 v9, v9, 0x1

    goto :goto_5

    :cond_9
    iget v4, v2, LD/D0;->u:I

    invoke-virtual {v2, v6}, LD/D0;->E(I)LD/L;

    iget-object v4, v0, LD/D0;->b:[I

    invoke-virtual {v0, v4, v1}, LD/D0;->w([II)I

    move-result v4

    if-nez p5, :cond_a

    const/4 v3, 0x1

    const/4 v9, 0x0

    goto :goto_7

    :cond_a
    if-eqz p3, :cond_e

    if-ltz v4, :cond_b

    const/4 v9, 0x1

    goto :goto_6

    :cond_b
    const/4 v9, 0x0

    :goto_6
    if-eqz v9, :cond_c

    invoke-virtual/range {p0 .. p0}, LD/D0;->F()V

    iget v3, v0, LD/D0;->s:I

    sub-int/2addr v4, v3

    invoke-virtual {v0, v4}, LD/D0;->a(I)V

    invoke-virtual/range {p0 .. p0}, LD/D0;->F()V

    :cond_c
    iget v3, v0, LD/D0;->s:I

    sub-int/2addr v1, v3

    invoke-virtual {v0, v1}, LD/D0;->a(I)V

    invoke-virtual/range {p0 .. p0}, LD/D0;->y()Z

    move-result v1

    if-eqz v9, :cond_d

    invoke-virtual/range {p0 .. p0}, LD/D0;->B()V

    invoke-virtual/range {p0 .. p0}, LD/D0;->i()V

    invoke-virtual/range {p0 .. p0}, LD/D0;->B()V

    invoke-virtual/range {p0 .. p0}, LD/D0;->i()V

    :cond_d
    move v9, v1

    const/4 v3, 0x1

    goto :goto_7

    :cond_e
    invoke-virtual {v0, v1, v3}, LD/D0;->z(II)Z

    move-result v9

    const/4 v3, 0x1

    sub-int/2addr v1, v3

    invoke-virtual {v0, v5, v7, v1}, LD/D0;->A(III)V

    :goto_7
    if-nez v9, :cond_12

    iget v0, v2, LD/D0;->o:I

    move/from16 v1, v19

    invoke-static {v11, v1}, LD/d;->j([II)Z

    move-result v4

    if-eqz v4, :cond_f

    move v8, v3

    goto :goto_8

    :cond_f
    invoke-static {v11, v1}, LD/d;->l([II)I

    move-result v8

    :goto_8
    add-int/2addr v0, v8

    iput v0, v2, LD/D0;->o:I

    if-eqz p4, :cond_10

    move/from16 v12, v20

    iput v12, v2, LD/D0;->s:I

    add-int v13, v17, v7

    iput v13, v2, LD/D0;->i:I

    :cond_10
    if-eqz v18, :cond_11

    invoke-virtual {v2, v6}, LD/D0;->J(I)V

    :cond_11
    return-object v10

    :cond_12
    const-string v0, "Unexpectedly removed anchors"

    invoke-static {v0}, LD/d;->r(Ljava/lang/String;)V

    const/4 v0, 0x0

    throw v0
.end method
