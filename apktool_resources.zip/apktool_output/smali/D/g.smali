.class public final LD/g;
.super Lp2/h;
.source "SourceFile"

# interfaces
.implements Lo2/c;


# instance fields
.field public final synthetic e:I

.field public final synthetic f:Ljava/lang/Object;

.field public final synthetic g:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;ILjava/lang/Object;)V
    .locals 0

    iput p2, p0, LD/g;->e:I

    iput-object p1, p0, LD/g;->f:Ljava/lang/Object;

    iput-object p3, p0, LD/g;->g:Ljava/lang/Object;

    const/4 p1, 0x1

    invoke-direct {p0, p1}, Lp2/h;-><init>(I)V

    return-void
.end method

.method private final b(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 9

    check-cast p1, Lo0/l;

    iget-object v0, p0, LD/g;->f:Ljava/lang/Object;

    check-cast v0, Lo0/b1;

    iget-boolean v1, v0, Lo0/b1;->f:Z

    if-nez v1, :cond_7

    iget-object p1, p1, Lo0/l;->a:Landroidx/lifecycle/r;

    invoke-interface {p1}, Landroidx/lifecycle/r;->c()Landroidx/lifecycle/t;

    move-result-object p1

    iget-object v1, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v1, LL/a;

    iput-object v1, v0, Lo0/b1;->h:LL/a;

    iget-object v2, v0, Lo0/b1;->g:Landroidx/lifecycle/t;

    if-nez v2, :cond_0

    iput-object p1, v0, Lo0/b1;->g:Landroidx/lifecycle/t;

    invoke-virtual {p1, v0}, Landroidx/lifecycle/t;->a(Landroidx/lifecycle/q;)V

    goto/16 :goto_4

    :cond_0
    iget-object p1, p1, Landroidx/lifecycle/t;->c:Landroidx/lifecycle/m;

    sget-object v2, Landroidx/lifecycle/m;->f:Landroidx/lifecycle/m;

    invoke-virtual {p1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result p1

    if-ltz p1, :cond_7

    new-instance p1, Lo0/a1;

    const/4 v2, 0x1

    invoke-direct {p1, v0, v1, v2}, Lo0/a1;-><init>(Lo0/b1;LL/a;I)V

    new-instance v1, LL/a;

    const v2, -0x773f589e

    const/4 v3, 0x1

    invoke-direct {v1, v2, v3, p1}, LL/a;-><init>(IZLp2/h;)V

    iget-object p1, v0, Lo0/b1;->e:LD/t;

    iget-boolean v0, p1, LD/t;->u:Z

    const/4 v2, 0x0

    if-nez v0, :cond_6

    iget-object v0, p1, LD/t;->d:LD/q;

    check-cast v0, LD/v0;

    iget-object v4, p1, LD/t;->t:LD/n;

    iget-boolean v4, v4, LD/n;->C:Z

    :try_start_0
    new-instance v5, LD/y;

    const/4 v6, 0x2

    invoke-direct {v5, v6, p1}, LD/y;-><init>(ILjava/lang/Object;)V

    new-instance v6, LD/g;

    const/4 v7, 0x3

    invoke-direct {v6, p1, v7, v2}, LD/g;-><init>(Ljava/lang/Object;ILjava/lang/Object;)V

    invoke-static {}, LN/o;->k()LN/h;

    move-result-object v7

    instance-of v8, v7, LN/c;

    if-eqz v8, :cond_1

    check-cast v7, LN/c;

    goto :goto_0

    :cond_1
    move-object v7, v2

    :goto_0
    if-eqz v7, :cond_5

    invoke-virtual {v7, v5, v6}, LN/c;->B(Lo2/c;Lo2/c;)LN/c;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_2

    if-eqz v5, :cond_5

    :try_start_1
    invoke-virtual {v5}, LN/h;->j()LN/h;

    move-result-object v6
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_3

    :try_start_2
    invoke-virtual {p1, v1}, LD/t;->i(LL/a;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :try_start_3
    invoke-static {v6}, LN/h;->p(LN/h;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :try_start_4
    invoke-static {v5}, LD/v0;->c(LN/c;)V
    :try_end_4
    .catch Ljava/lang/Exception; {:try_start_4 .. :try_end_4} :catch_2

    if-nez v4, :cond_2

    invoke-static {}, LN/o;->k()LN/h;

    move-result-object v1

    invoke-virtual {v1}, LN/h;->m()V

    :cond_2
    iget-object v1, v0, LD/v0;->b:Ljava/lang/Object;

    monitor-enter v1

    :try_start_5
    iget-object v5, v0, LD/v0;->r:LB2/G;

    invoke-virtual {v5}, LB2/G;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, LD/o0;

    sget-object v6, LD/o0;->e:LD/o0;

    invoke-virtual {v5, v6}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    move-result v5

    if-lez v5, :cond_3

    invoke-virtual {v0}, LD/v0;->h()Ljava/util/List;

    move-result-object v5

    invoke-interface {v5, p1}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_3

    iget-object v5, v0, LD/v0;->e:Ljava/util/ArrayList;

    invoke-virtual {v5, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    iput-object v2, v0, LD/v0;->f:Ljava/lang/Object;
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception p1

    goto :goto_2

    :cond_3
    :goto_1
    monitor-exit v1

    :try_start_6
    iget-object v1, v0, LD/v0;->b:Ljava/lang/Object;

    monitor-enter v1
    :try_end_6
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1

    :try_start_7
    iget-object v2, v0, LD/v0;->j:Ljava/util/ArrayList;

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v5
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    const/4 v6, 0x0

    if-gtz v5, :cond_4

    :try_start_8
    monitor-exit v1
    :try_end_8
    .catch Ljava/lang/Exception; {:try_start_8 .. :try_end_8} :catch_1

    :try_start_9
    invoke-virtual {p1}, LD/t;->d()V

    invoke-virtual {p1}, LD/t;->f()V
    :try_end_9
    .catch Ljava/lang/Exception; {:try_start_9 .. :try_end_9} :catch_0

    if-nez v4, :cond_7

    invoke-static {}, LN/o;->k()LN/h;

    move-result-object p1

    invoke-virtual {p1}, LN/h;->m()V

    goto :goto_4

    :catch_0
    move-exception p1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0, p1, v2, v1}, LD/v0;->l(LD/v0;Ljava/lang/Exception;ZI)V

    goto :goto_4

    :cond_4
    :try_start_a
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, LD/X;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v2, 0x0

    throw v2
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    :catchall_1
    move-exception v2

    :try_start_b
    monitor-exit v1

    throw v2
    :try_end_b
    .catch Ljava/lang/Exception; {:try_start_b .. :try_end_b} :catch_1

    :catch_1
    move-exception v1

    invoke-virtual {v0, v1, p1, v3}, LD/v0;->k(Ljava/lang/Exception;LD/t;Z)V

    goto :goto_4

    :goto_2
    monitor-exit v1

    throw p1

    :catchall_2
    move-exception v1

    :try_start_c
    invoke-static {v6}, LN/h;->p(LN/h;)V

    throw v1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    :catchall_3
    move-exception v1

    :try_start_d
    invoke-static {v5}, LD/v0;->c(LN/c;)V

    throw v1

    :catch_2
    move-exception v1

    goto :goto_3

    :cond_5
    new-instance v1, Ljava/lang/IllegalStateException;

    const-string v2, "Cannot create a mutable snapshot of an read-only snapshot"

    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v1
    :try_end_d
    .catch Ljava/lang/Exception; {:try_start_d .. :try_end_d} :catch_2

    :goto_3
    invoke-virtual {v0, v1, p1, v3}, LD/v0;->k(Ljava/lang/Exception;LD/t;Z)V

    goto :goto_4

    :cond_6
    const-string p1, "The composition is disposed"

    invoke-static {p1}, LD/d;->I(Ljava/lang/String;)V

    throw v2

    :cond_7
    :goto_4
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1
.end method


# virtual methods
.method public final i(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    iget v0, p0, LD/g;->e:I

    packed-switch v0, :pswitch_data_0

    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, Lz2/c;

    iget-object p1, p1, Lz2/c;->f:Landroid/os/Handler;

    iget-object v0, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v0, LD2/h;

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_0
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/g;->g:Ljava/lang/Object;

    check-cast p1, Ls/f;

    iget-object v0, p0, LD/g;->f:Ljava/lang/Object;

    check-cast v0, Ls/g;

    invoke-virtual {v0, p1}, Ls/g;->b(Ls/f;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_1
    invoke-direct {p0, p1}, LD/g;->b(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    return-object p1

    :pswitch_2
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, LD/h0;

    iget-object p1, p1, LD/h0;->e:Ljava/lang/Object;

    check-cast p1, Landroid/view/Choreographer;

    iget-object v0, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v0, LD/z;

    invoke-virtual {p1, v0}, Landroid/view/Choreographer;->removeFrameCallback(Landroid/view/Choreographer$FrameCallback;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_3
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, Lo0/W;

    iget-object v0, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v0, LD/z;

    iget-object v1, p1, Lo0/W;->h:Ljava/lang/Object;

    monitor-enter v1

    :try_start_0
    iget-object p1, p1, Lo0/W;->j:Ljava/util/ArrayList;

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    monitor-exit v1

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :catchall_0
    move-exception p1

    monitor-exit v1

    throw p1

    :pswitch_4
    check-cast p1, LD/G;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v1, Lo0/Q;

    invoke-virtual {v0, v1}, Landroid/content/Context;->registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    new-instance v0, Lo0/O;

    const/4 v2, 0x1

    invoke-direct {v0, p1, v1, v2}, Lo0/O;-><init>(Landroid/content/Context;Landroid/content/ComponentCallbacks2;I)V

    return-object v0

    :pswitch_5
    check-cast p1, LD/G;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, Landroid/content/Context;

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    iget-object v1, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v1, Lo0/P;

    invoke-virtual {v0, v1}, Landroid/content/Context;->registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    new-instance v0, Lo0/O;

    const/4 v2, 0x0

    invoke-direct {v0, p1, v1, v2}, Lo0/O;-><init>(Landroid/content/Context;Landroid/content/ComponentCallbacks2;I)V

    return-object v0

    :pswitch_6
    check-cast p1, Ll0/n;

    iget-object v0, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v0, LW/I;

    iget-object v0, v0, LW/I;->G:LD/y;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x0

    invoke-static {v1, v1}, Lr2/a;->c(II)J

    move-result-wide v1

    iget-object v3, p0, LD/g;->f:Ljava/lang/Object;

    check-cast v3, Ll0/o;

    invoke-static {p1, v3}, Ll0/n;->a(Ll0/n;Ll0/o;)V

    iget-wide v4, v3, Ll0/o;->h:J

    invoke-static {v1, v2, v4, v5}, La/a;->X(JJ)J

    move-result-wide v1

    const/4 p1, 0x0

    invoke-virtual {v3, v1, v2, p1, v0}, Ll0/o;->G(JFLo2/c;)V

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_7
    iget-object v0, p0, LD/g;->f:Ljava/lang/Object;

    check-cast v0, LD/t;

    invoke-virtual {v0, p1}, LD/t;->u(Ljava/lang/Object;)V

    iget-object v0, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v0, Ln/B;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Ln/B;->a(Ljava/lang/Object;)Z

    :cond_0
    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :pswitch_8
    check-cast p1, Ljava/lang/Throwable;

    iget-object v0, p0, LD/g;->f:Ljava/lang/Object;

    check-cast v0, LD/v0;

    iget-object v1, v0, LD/v0;->b:Ljava/lang/Object;

    iget-object v2, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v2, Ljava/lang/Throwable;

    monitor-enter v1

    const/4 v3, 0x0

    if-eqz v2, :cond_2

    if-eqz p1, :cond_3

    :try_start_1
    instance-of v4, p1, Ljava/util/concurrent/CancellationException;

    if-nez v4, :cond_1

    goto :goto_0

    :cond_1
    move-object p1, v3

    :goto_0
    if-eqz p1, :cond_3

    invoke-static {v2, p1}, LZ0/d;->f(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    goto :goto_1

    :catchall_1
    move-exception p1

    goto :goto_2

    :cond_2
    move-object v2, v3

    :cond_3
    :goto_1
    iput-object v2, v0, LD/v0;->d:Ljava/lang/Throwable;

    iget-object p1, v0, LD/v0;->r:LB2/G;

    sget-object v0, LD/o0;->d:LD/o0;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p1, v3, v0}, LB2/G;->g(Ljava/lang/Object;Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    monitor-exit v1

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :goto_2
    monitor-exit v1

    throw p1

    :pswitch_9
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, LD/Q;

    iget-object v0, p1, LD/Q;->a:Ljava/lang/Object;

    iget-object v1, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v1, Ly2/f;

    monitor-enter v0

    :try_start_2
    iget-object p1, p1, LD/Q;->b:Ljava/util/ArrayList;

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    monitor-exit v0

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :catchall_2
    move-exception p1

    monitor-exit v0

    throw p1

    :pswitch_a
    check-cast p1, Ljava/lang/Throwable;

    iget-object p1, p0, LD/g;->f:Ljava/lang/Object;

    check-cast p1, LD/h;

    iget-object v0, p1, LD/h;->e:Ljava/lang/Object;

    iget-object v1, p0, LD/g;->g:Ljava/lang/Object;

    check-cast v1, LD/f;

    monitor-enter v0

    :try_start_3
    iget-object v2, p1, LD/h;->g:Ljava/util/ArrayList;

    invoke-virtual {v2, v1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    iget-object v1, p1, LD/h;->g:Ljava/util/ArrayList;

    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_4

    iget-object p1, p1, LD/h;->i:LD/e;

    const/4 v1, 0x0

    invoke-virtual {p1, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    goto :goto_3

    :catchall_3
    move-exception p1

    goto :goto_4

    :cond_4
    :goto_3
    monitor-exit v0

    sget-object p1, Lc2/m;->a:Lc2/m;

    return-object p1

    :goto_4
    monitor-exit v0

    throw p1

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method
