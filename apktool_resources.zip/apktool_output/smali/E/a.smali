.class public final LE/a;
.super Lr2/a;
.source "SourceFile"


# instance fields
.field public final b:LE/A;


# direct methods
.method public constructor <init>()V
    .locals 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, LE/A;

    invoke-direct {v0}, LE/A;-><init>()V

    iput-object v0, p0, LE/a;->b:LE/A;

    return-void
.end method
